import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { WorksView } from "./components/WorksView";
import { ProjectDetailModal } from "./components/ProjectDetailModal";
import { StudioView } from "./components/StudioView";
import { NewsView } from "./components/NewsView";
import { PublicationsView } from "./components/PublicationsView";
import { ContactView } from "./components/ContactView";
import { ShortlistModal } from "./components/ShortlistModal";
import { AiConsultantDrawer } from "./components/AiConsultantDrawer";
import { PROJECTS_DATA } from "./data/projectsData";
import { ActivePage, Project, ProjectCategory } from "./types";

export default function App() {
  const [activePage, setActivePage] = useState<ActivePage>("works");
  const [selectedCategory, setSelectedCategory] = useState<ProjectCategory>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Dark Mode State
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem("oppenheim_theme");
    return saved ? saved === "dark" : true; // Default to dark mode for luxury architectural vibe
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("oppenheim_theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("oppenheim_theme", "light");
    }
  }, [darkMode]);

  // Saved Shortlist / Favorites
  const [shortlist, setShortlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("oppenheim_shortlist");
      return saved ? JSON.parse(saved) : ["desert-rock", "ayla-golf-clubhouse"];
    } catch {
      return ["desert-rock", "ayla-golf-clubhouse"];
    }
  });

  useEffect(() => {
    localStorage.setItem("oppenheim_shortlist", JSON.stringify(shortlist));
  }, [shortlist]);

  const handleToggleShortlist = (projectId: string) => {
    setShortlist((prev) =>
      prev.includes(projectId) ? prev.filter((id) => id !== projectId) : [...prev, projectId]
    );
  };

  const handleClearShortlist = () => setShortlist([]);

  // Selected Project for Detail View Modal
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  // Modals & Drawers
  const [shortlistOpen, setShortlistOpen] = useState(false);
  const [aiConsultantOpen, setAiConsultantOpen] = useState(false);
  const [aiConsultantPrompt, setAiConsultantPrompt] = useState<string>("");

  const handleOpenAiConsultantWithContext = (prompt: string) => {
    setAiConsultantPrompt(prompt);
    setAiConsultantOpen(true);
  };

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 transition-colors duration-300 font-sans selection:bg-amber-800 selection:text-white">
      {/* Fixed Sticky Header */}
      <Header
        activePage={activePage}
        setActivePage={setActivePage}
        shortlistCount={shortlist.length}
        onOpenShortlist={() => setShortlistOpen(true)}
        onOpenAiConsultant={() => {
          setAiConsultantPrompt("");
          setAiConsultantOpen(true);
        }}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Main Page Views */}
      <main id="main-content" className="relative">
        {activePage === "works" && (
          <WorksView
            projects={PROJECTS_DATA}
            onSelectProject={(p) => setSelectedProject(p)}
            shortlist={shortlist}
            onToggleShortlist={handleToggleShortlist}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            onOpenAiConsultant={() => setAiConsultantOpen(true)}
          />
        )}

        {activePage === "studio" && <StudioView setActivePage={setActivePage} />}

        {activePage === "news" && <NewsView />}

        {activePage === "publications" && <PublicationsView />}

        {activePage === "contact" && <ContactView />}
      </main>

      {/* Project Detail Fullscreen Modal */}
      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        shortlist={shortlist}
        onToggleShortlist={handleToggleShortlist}
        allProjects={PROJECTS_DATA}
        onSelectProject={(p) => setSelectedProject(p)}
        onOpenAiConsultantWithContext={handleOpenAiConsultantWithContext}
      />

      {/* Shortlist Drawer Modal */}
      <ShortlistModal
        isOpen={shortlistOpen}
        onClose={() => setShortlistOpen(false)}
        shortlist={shortlist}
        allProjects={PROJECTS_DATA}
        onRemoveFromShortlist={handleToggleShortlist}
        onClearShortlist={handleClearShortlist}
        onSelectProject={(p) => setSelectedProject(p)}
      />

      {/* AI Consultant Drawer */}
      <AiConsultantDrawer
        isOpen={aiConsultantOpen}
        onClose={() => setAiConsultantOpen(false)}
        initialPrompt={aiConsultantPrompt}
      />

      {/* Footer */}
      <Footer setActivePage={setActivePage} />
    </div>
  );
}
