export type ProjectCategory =
  | "All"
  | "Hospitality"
  | "Residential"
  | "Commercial & Mixed-Use"
  | "Cultural & Civic"
  | "Masterplanning"
  | "Interior Design";

export type ViewMode = "grid-2" | "grid-3" | "grid-4" | "list" | "fullscreen";

export interface ProjectDiagram {
  title: string;
  image: string;
}

export interface Project {
  id: string;
  title: string;
  subtitle: string;
  category: ProjectCategory;
  location: string;
  year: number | string;
  area: string;
  status: "Completed" | "In Construction" | "Design Phase" | "Concept";
  heroImage: string;
  images: string[];
  description: string;
  longDescription: string;
  highlights: string[];
  materials: string[];
  awards: string[];
  team: string[];
  client: string;
  featured: boolean;
  aspectRatio?: "aspect-[4/3]" | "aspect-[3/4]" | "aspect-[16/9]" | "aspect-square";
  coordinates: {
    lat: number;
    lng: number;
  };
  diagrams?: ProjectDiagram[];
  quote?: {
    text: string;
    author: string;
  };
}

export interface StudioOffice {
  id: string;
  city: string;
  country: string;
  address: string;
  phone: string;
  email: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  image: string;
  manager: string;
  timezone: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  category: "Press Release" | "Award" | "Publication" | "Lecture" | "Feature";
  date: string;
  publication: string;
  summary: string;
  content: string;
  image: string;
  readTime: string;
  featured?: boolean;
}

export interface BookPublication {
  id: string;
  title: string;
  subtitle: string;
  publisher: string;
  year: string;
  coverImage: string;
  spreadImages: string[];
  description: string;
  isbn: string;
  pages: number;
  purchaseUrl: string;
}

export interface CareerRole {
  id: string;
  title: string;
  office: string;
  type: string;
  experience: string;
  description: string;
  requirements: string[];
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  office: string;
  bio: string;
  image: string;
}

export interface AwardItem {
  year: string;
  award: string;
  project: string;
  organization: string;
}

export type ActivePage = "works" | "studio" | "news" | "publications" | "contact";
