import React, { useState } from "react";
import { Project } from "../types";
import {
  X,
  Heart,
  MapPin,
  Calendar,
  Layers,
  Award,
  Users,
  Building,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Share2,
  Check
} from "lucide-react";

interface ProjectDetailModalProps {
  project: Project | null;
  onClose: () => void;
  shortlist: string[];
  onToggleShortlist: (projectId: string) => void;
  allProjects: Project[];
  onSelectProject: (p: Project) => void;
  onOpenAiConsultantWithContext: (contextText: string) => void;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  shortlist,
  onToggleShortlist,
  allProjects,
  onSelectProject,
  onOpenAiConsultantWithContext,
}) => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!project) return null;

  const isShortlisted = shortlist.includes(project.id);
  const currentProjectIndex = allProjects.findIndex((p) => p.id === project.id);
  const prevProject = allProjects[currentProjectIndex - 1] || allProjects[allProjects.length - 1];
  const nextProject = allProjects[currentProjectIndex + 1] || allProjects[0];

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const currentImage = project.images[selectedImageIndex] || project.heroImage;

  return (
    <div
      id="project-detail-modal-overlay"
      className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/95 backdrop-blur-md text-stone-100 animate-fadeIn"
    >
      {/* Top Floating Control Bar */}
      <div className="sticky top-0 z-50 bg-stone-950/90 border-b border-stone-800 px-4 sm:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3 text-xs uppercase tracking-widest text-stone-400 font-mono">
          <span className="text-stone-200 font-bold">{project.category}</span>
          <span>•</span>
          <span>{project.location}</span>
        </div>

        <div className="flex items-center space-x-3">
          {/* Ask AI Button */}
          <button
            onClick={() =>
              onOpenAiConsultantWithContext(
                `Tell me detailed architectural insights about "${project.title}" in ${project.location}.`
              )
            }
            className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 bg-amber-900/60 hover:bg-amber-900/90 text-amber-200 border border-amber-700/50 text-xs font-mono rounded-none uppercase tracking-wider transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Project Analysis</span>
          </button>

          {/* Shortlist Toggle */}
          <button
            onClick={() => onToggleShortlist(project.id)}
            className={`p-2 rounded-full border transition-colors ${
              isShortlisted
                ? "bg-red-600 border-red-500 text-white"
                : "border-stone-700 text-stone-300 hover:border-stone-400"
            }`}
            title="Shortlist"
          >
            <Heart className={`w-4 h-4 ${isShortlisted ? "fill-white" : ""}`} />
          </button>

          {/* Share Link */}
          <button
            onClick={handleCopyLink}
            className="p-2 rounded-full border border-stone-700 text-stone-300 hover:border-stone-400 transition-colors"
            title="Copy project link"
          >
            {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
          </button>

          {/* Close Modal */}
          <button
            onClick={onClose}
            className="p-2 rounded-full border border-stone-700 text-stone-100 hover:bg-stone-800 transition-colors ml-2"
            aria-label="Close Project View"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Project Title Header */}
        <div className="mb-10 text-left">
          <p className="text-xs uppercase tracking-[0.3em] text-stone-400 font-mono mb-2">
            {project.location} • {project.year}
          </p>
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif font-light text-white tracking-wide mb-3">
            {project.title}
          </h1>
          <p className="text-base sm:text-xl text-stone-300 font-light max-w-3xl leading-relaxed">
            {project.subtitle}
          </p>
        </div>

        {/* Gallery Section */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-16">
          {/* Main Selected Image */}
          <div className="lg:col-span-3 relative bg-stone-900 border border-stone-800 group overflow-hidden aspect-[16/10]">
            <img
              src={currentImage}
              alt={project.title}
              className="w-full h-full object-cover transition-all duration-500"
            />
            <button
              onClick={() => setLightboxOpen(true)}
              className="absolute bottom-4 right-4 p-2.5 bg-stone-950/80 hover:bg-stone-950 text-white border border-stone-700 transition-colors shadow-lg"
              title="Expand Lightbox"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>

          {/* Gallery Thumbnails List */}
          <div className="flex lg:flex-col gap-3 overflow-x-auto lg:overflow-y-auto max-h-[500px] no-scrollbar">
            {project.images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedImageIndex(idx)}
                className={`relative shrink-0 w-24 h-20 lg:w-full lg:h-28 overflow-hidden border transition-all ${
                  selectedImageIndex === idx
                    ? "border-amber-400 ring-1 ring-amber-400 opacity-100"
                    : "border-stone-800 opacity-60 hover:opacity-100"
                }`}
              >
                <img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Specifications & Overview Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 border-t border-stone-800 pt-12 mb-16">
          {/* Left Columns: Story & Narrative */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-stone-400 mb-3">
                Architectural Concept
              </h3>
              <p className="text-base sm:text-lg font-light text-stone-200 leading-relaxed font-sans">
                {project.longDescription || project.description}
              </p>
            </div>

            {/* Principal Quote Callout */}
            {project.quote && (
              <blockquote className="p-6 bg-stone-900/90 border-l-2 border-amber-400 my-6">
                <p className="text-lg font-serif italic text-stone-200 leading-relaxed">
                  "{project.quote.text}"
                </p>
                <cite className="block text-xs uppercase tracking-widest text-amber-400 font-mono mt-3 not-italic">
                  — {project.quote.author}
                </cite>
              </blockquote>
            )}

            {/* Key Highlights */}
            {project.highlights && project.highlights.length > 0 && (
              <div>
                <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-stone-400 mb-4">
                  Spatial & Technical Innovations
                </h3>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-stone-300 font-light">
                  {project.highlights.map((item, idx) => (
                    <li key={idx} className="flex items-start space-x-2.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Materials Palette */}
            {project.materials && project.materials.length > 0 && (
              <div>
                <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-stone-400 mb-3">
                  Materiality & Tectonic Elements
                </h3>
                <div className="flex flex-wrap gap-2">
                  {project.materials.map((mat) => (
                    <span
                      key={mat}
                      className="px-3 py-1.5 bg-stone-900 border border-stone-800 text-xs font-mono text-stone-300 uppercase tracking-wider"
                    >
                      {mat}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Project Metadata Card */}
          <div className="bg-stone-900/80 border border-stone-800 p-6 sm:p-8 space-y-6 h-fit">
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-amber-400 pb-4 border-b border-stone-800">
              Project Data Sheet
            </h3>

            <div className="space-y-4 text-xs font-mono">
              <div className="flex items-center justify-between py-1 border-b border-stone-800/60">
                <span className="text-stone-400 flex items-center space-x-2">
                  <MapPin className="w-3.5 h-3.5 text-stone-500" />
                  <span>Location</span>
                </span>
                <span className="text-stone-200 text-right">{project.location}</span>
              </div>

              <div className="flex items-center justify-between py-1 border-b border-stone-800/60">
                <span className="text-stone-400 flex items-center space-x-2">
                  <Calendar className="w-3.5 h-3.5 text-stone-500" />
                  <span>Year</span>
                </span>
                <span className="text-stone-200">{project.year}</span>
              </div>

              <div className="flex items-center justify-between py-1 border-b border-stone-800/60">
                <span className="text-stone-400 flex items-center space-x-2">
                  <Layers className="w-3.5 h-3.5 text-stone-500" />
                  <span>Area</span>
                </span>
                <span className="text-stone-200">{project.area}</span>
              </div>

              <div className="flex items-center justify-between py-1 border-b border-stone-800/60">
                <span className="text-stone-400 flex items-center space-x-2">
                  <Building className="w-3.5 h-3.5 text-stone-500" />
                  <span>Status</span>
                </span>
                <span className="text-emerald-400 font-bold">{project.status}</span>
              </div>

              {project.client && (
                <div className="flex items-center justify-between py-1 border-b border-stone-800/60">
                  <span className="text-stone-400">Client</span>
                  <span className="text-stone-200 text-right">{project.client}</span>
                </div>
              )}
            </div>

            {/* Team Members */}
            {project.team && project.team.length > 0 && (
              <div className="pt-2">
                <span className="text-stone-400 text-xs font-mono uppercase tracking-wider block mb-2 flex items-center space-x-2">
                  <Users className="w-3.5 h-3.5 text-stone-500" />
                  <span>Studio Team</span>
                </span>
                <p className="text-xs text-stone-300 font-light leading-relaxed">
                  {project.team.join(", ")}
                </p>
              </div>
            )}

            {/* Awards Received */}
            {project.awards && project.awards.length > 0 && (
              <div className="pt-2 border-t border-stone-800/80">
                <span className="text-stone-400 text-xs font-mono uppercase tracking-wider block mb-2 flex items-center space-x-2">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  <span>Recognition</span>
                </span>
                <ul className="space-y-1.5 text-xs text-stone-300 font-light">
                  {project.awards.map((award, i) => (
                    <li key={i} className="text-stone-300 flex items-start space-x-2">
                      <span className="text-amber-400">✦</span>
                      <span>{award}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Coordinates / Location Badge */}
            <div className="pt-4 border-t border-stone-800 text-[10px] font-mono text-stone-500 flex justify-between">
              <span>GPS COORDS</span>
              <span>
                {project.coordinates.lat.toFixed(3)}°N, {project.coordinates.lng.toFixed(3)}°E
              </span>
            </div>
          </div>
        </div>

        {/* Architectural Diagrams & Floorplans Section */}
        {project.diagrams && project.diagrams.length > 0 && (
          <div className="border-t border-stone-800 pt-12 mb-16">
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-stone-400 mb-6">
              Architectural Diagrams & Environmental Studies
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {project.diagrams.map((diag, idx) => (
                <div key={idx} className="bg-stone-900 border border-stone-800 p-4">
                  <img src={diag.image} alt={diag.title} className="w-full h-64 object-cover mb-3" />
                  <p className="text-xs font-mono text-stone-300 uppercase tracking-wider">
                    {diag.title}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer Project Navigation Switcher */}
        <div className="border-t border-stone-800 pt-8 flex items-center justify-between text-xs font-mono">
          <button
            onClick={() => onSelectProject(prevProject)}
            className="flex items-center space-x-2 text-stone-400 hover:text-white transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>PREV: {prevProject.title}</span>
          </button>

          <button
            onClick={() => onSelectProject(nextProject)}
            className="flex items-center space-x-2 text-stone-400 hover:text-white transition-colors"
          >
            <span>NEXT: {nextProject.title}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Lightbox Modal */}
      {lightboxOpen && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4">
          <button
            onClick={() => setLightboxOpen(false)}
            className="absolute top-6 right-6 p-3 text-white hover:text-stone-300"
          >
            <X className="w-8 h-8" />
          </button>
          <img
            src={currentImage}
            alt={project.title}
            className="max-w-full max-h-[90vh] object-contain shadow-2xl"
          />
        </div>
      )}
    </div>
  );
};
