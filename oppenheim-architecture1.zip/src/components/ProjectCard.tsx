import React, { useState } from "react";
import { Project } from "../types";
import { Heart, ArrowUpRight, MapPin, Calendar } from "lucide-react";

interface ProjectCardProps {
  project: Project;
  onSelectProject: (project: Project) => void;
  isShortlisted: boolean;
  onToggleShortlist: (projectId: string) => void;
  viewMode: string;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  onSelectProject,
  isShortlisted,
  onToggleShortlist,
}) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMousePos({ x, y });
  };

  const handleMouseEnter = () => setIsHovered(true);
  const handleMouseLeave = () => {
    setIsHovered(false);
    setMousePos({ x: 0, y: 0 });
  };

  return (
    <div
      id={`project-card-${project.id}`}
      className="group relative flex flex-col bg-white dark:bg-stone-900 border border-stone-200/90 dark:border-stone-800/90 overflow-hidden cursor-pointer transition-all duration-500 hover:shadow-2xl hover:-translate-y-1.5 hover:border-stone-400 dark:hover:border-stone-600"
      onClick={() => onSelectProject(project)}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Image Frame Container */}
      <div className={`relative w-full overflow-hidden bg-stone-950 ${project.aspectRatio || "aspect-[4/3]"}`}>
        {/* Parallax & Zoom Image */}
        <img
          src={project.heroImage}
          alt={project.title}
          className="w-full h-full object-cover will-change-transform"
          style={{
            transform: isHovered
              ? `scale(1.14) translate(${mousePos.x * -14}px, ${mousePos.y * -14}px)`
              : "scale(1) translate(0px, 0px)",
            transition: isHovered
              ? "transform 0.15s ease-out, filter 0.5s ease"
              : "transform 0.8s cubic-bezier(0.16, 1, 0.3, 1), filter 0.5s ease",
            filter: isHovered ? "brightness(1.05) contrast(1.03)" : "brightness(1)",
          }}
          loading="lazy"
        />

        {/* Subtle Shimmer Overlay Sweep */}
        <div className="absolute inset-0 bg-gradient-to-tr from-stone-950/60 via-stone-950/20 to-transparent opacity-40 group-hover:opacity-20 transition-opacity duration-500" />

        {/* Dynamic Light Sweep Bar on Hover */}
        <div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent pointer-events-none transition-transform duration-1000 ease-in-out -translate-x-full group-hover:translate-x-full"
        />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10">
          <span className="px-2.5 py-1 bg-stone-950/80 text-stone-100 text-[10px] uppercase tracking-widest font-mono backdrop-blur-md border border-stone-800/60 shadow-sm">
            {project.category}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleShortlist(project.id);
            }}
            className={`pointer-events-auto p-2 rounded-full backdrop-blur-md transition-all transform hover:scale-110 ${
              isShortlisted
                ? "bg-red-600 text-white shadow-md"
                : "bg-stone-950/70 text-stone-200 hover:text-white hover:bg-stone-950/90 border border-stone-800/80"
            }`}
            title="Save to shortlist"
            aria-label="Bookmark Project"
          >
            <Heart className={`w-3.5 h-3.5 ${isShortlisted ? "fill-white" : ""}`} />
          </button>
        </div>

        {/* Floating Spec Elevation Watermark on Hover */}
        <div className="absolute bottom-3 left-3 pointer-events-none opacity-0 group-hover:opacity-100 transition-all duration-500 transform group-hover:translate-y-0 translate-y-2 z-10">
          <span className="text-[9px] font-mono uppercase tracking-widest text-amber-300 bg-stone-950/80 px-2 py-0.5 backdrop-blur-md border border-stone-800/80">
            {project.status} • {project.area}
          </span>
        </div>

        {/* Bottom Right Hover Action */}
        <div className="absolute bottom-3 right-3 pointer-events-none opacity-0 group-hover:opacity-100 transition-all duration-500 transform group-hover:translate-y-0 translate-y-2 z-10">
          <span className="inline-flex items-center space-x-1 px-3 py-1.5 bg-stone-100 text-stone-900 text-[10px] font-bold uppercase tracking-widest shadow-xl">
            <span>Explore</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </span>
        </div>
      </div>

      {/* Text Details below card */}
      <div className="p-5 flex flex-col flex-1 justify-between bg-white dark:bg-stone-900 transition-colors">
        <div>
          <div className="flex items-center justify-between text-[11px] text-stone-500 dark:text-stone-400 font-mono mb-1.5">
            <span className="flex items-center space-x-1">
              <MapPin className="w-3 h-3 text-stone-400 dark:text-stone-500" />
              <span>{project.location}</span>
            </span>
            <span className="flex items-center space-x-1">
              <Calendar className="w-3 h-3 text-stone-400 dark:text-stone-500" />
              <span>{project.year}</span>
            </span>
          </div>
          <h3 className="text-xl font-serif tracking-wide text-stone-900 dark:text-stone-50 group-hover:text-amber-800 dark:group-hover:text-amber-400 transition-colors leading-snug font-medium">
            {project.title}
          </h3>
          <p className="text-xs text-stone-600 dark:text-stone-300 font-light mt-1.5 line-clamp-2 leading-relaxed">
            {project.subtitle || project.description}
          </p>
        </div>

        {/* Material tags preview */}
        {project.materials && project.materials.length > 0 && (
          <div className="mt-4 pt-3 border-t border-stone-200 dark:border-stone-800 flex flex-wrap gap-1">
            {project.materials.slice(0, 3).map((mat) => (
              <span
                key={mat}
                className="text-[9px] uppercase tracking-wider text-stone-600 dark:text-stone-400 bg-stone-100 dark:bg-stone-800/80 px-2 py-0.5 font-mono"
              >
                {mat}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
