import React, { useState } from "react";
import { PHILOSOPHY_PILLARS, TEAM_MEMBERS, AWARDS_LIST, OFFICES } from "../data/studioData";
import { ActivePage, TeamMember } from "../types";
import { Award, Globe, Compass, ChevronDown, ChevronUp, MapPin, ArrowRight } from "lucide-react";

interface StudioViewProps {
  setActivePage: (page: ActivePage) => void;
}

export const StudioView: React.FC<StudioViewProps> = ({ setActivePage }) => {
  const [expandedPillar, setExpandedPillar] = useState<string | null>("01");
  const [selectedTeamMember, setSelectedTeamMember] = useState<TeamMember | null>(null);
  const [awardSearch, setAwardSearch] = useState("");

  const filteredAwards = AWARDS_LIST.filter(
    (item) =>
      !awardSearch ||
      item.award.toLowerCase().includes(awardSearch.toLowerCase()) ||
      item.project.toLowerCase().includes(awardSearch.toLowerCase()) ||
      item.organization.toLowerCase().includes(awardSearch.toLowerCase()) ||
      item.year.includes(awardSearch)
  );

  return (
    <div id="studio-page-container" className="pt-24 pb-20 min-h-screen">
      {/* Studio Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="border-b border-stone-200 dark:border-stone-800 pb-12">
          <p className="text-xs uppercase tracking-[0.35em] text-stone-500 font-mono mb-4">
            Studio Profile & Manifesto
          </p>
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-serif font-light text-stone-900 dark:text-stone-50 tracking-wide leading-tight mb-8">
            Design Following Life.<br />
            Form Following Feeling.
          </h1>
          <p className="text-base sm:text-xl font-light text-stone-600 dark:text-stone-300 max-w-3xl leading-relaxed">
            Founded in 1999 by Chad Oppenheim, Oppenheim Architecture is an international design practice based in Miami, Basel, and New York. We craft architectural environments that are deeply symbiotic with their natural context.
          </p>
        </div>
      </div>

      {/* Philosophy Pillars Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-24">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <span className="text-xs uppercase font-mono tracking-[0.25em] text-amber-700 dark:text-amber-400">
              Core Principles
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-light text-stone-900 dark:text-stone-100 mt-2">
              Our Design Philosophy
            </h2>
          </div>
          <p className="text-xs text-stone-500 max-w-md mt-4 md:mt-0 font-light">
            Every project begins with a deep study of site hydrology, ancient topography, and human ritual.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {PHILOSOPHY_PILLARS.map((pillar) => {
            const isExpanded = expandedPillar === pillar.number;
            return (
              <div
                key={pillar.number}
                className={`p-8 border transition-all duration-300 cursor-pointer ${
                  isExpanded
                    ? "bg-stone-900 text-stone-100 border-stone-800 shadow-lg"
                    : "bg-stone-100/70 dark:bg-stone-900/40 text-stone-900 dark:text-stone-200 border-stone-200 dark:border-stone-800 hover:border-stone-400"
                }`}
                onClick={() => setExpandedPillar(isExpanded ? null : pillar.number)}
              >
                <div className="flex items-center justify-between mb-4">
                  <span
                    className={`text-2xl font-mono font-bold ${
                      isExpanded ? "text-amber-400" : "text-stone-400"
                    }`}
                  >
                    {pillar.number}
                  </span>
                  <button className="p-1">
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5 text-amber-400" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-stone-400" />
                    )}
                  </button>
                </div>
                <h3 className="text-2xl font-serif mb-2 tracking-wide">{pillar.title}</h3>
                <p
                  className={`text-sm font-light leading-relaxed mb-4 ${
                    isExpanded ? "text-stone-300" : "text-stone-600 dark:text-stone-400"
                  }`}
                >
                  {pillar.summary}
                </p>
                {isExpanded && (
                  <div className="pt-4 border-t border-stone-800 text-xs font-light text-stone-300 leading-relaxed animate-fadeIn">
                    {pillar.details}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Studio Locations Grid */}
      <div className="bg-stone-900 text-stone-100 py-20 mb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-amber-400">
              International Offices
            </span>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-white mt-2">
              Miami • Basel • New York
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {OFFICES.map((office) => (
              <div
                key={office.id}
                className="bg-stone-950 border border-stone-800 overflow-hidden group hover:border-stone-700 transition-all"
              >
                <div className="h-48 overflow-hidden relative">
                  <img
                    src={office.image}
                    alt={office.city}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-80"
                  />
                  <div className="absolute top-3 right-3 bg-stone-950/80 px-2.5 py-1 text-[10px] font-mono uppercase tracking-widest text-stone-300">
                    {office.timezone}
                  </div>
                </div>
                <div className="p-6 space-y-3">
                  <div className="flex items-center space-x-2 text-amber-400 text-xs font-mono uppercase tracking-wider">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{office.city}, {office.country}</span>
                  </div>
                  <h3 className="text-xl font-serif text-white">{office.city} Studio</h3>
                  <p className="text-xs text-stone-400 font-light leading-relaxed">
                    {office.address}
                  </p>
                  <p className="text-xs text-stone-500 font-mono">{office.phone}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button
              onClick={() => setActivePage("contact")}
              className="inline-flex items-center space-x-2 px-6 py-3 bg-stone-100 text-stone-900 hover:bg-white text-xs uppercase tracking-widest font-semibold transition-colors shadow-sm"
            >
              <span>Contact Studio Offices</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Leadership & Principal Showcase */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-24">
        <div className="mb-12">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-amber-700 dark:text-amber-400">
            Design Leadership
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-light text-stone-900 dark:text-stone-100 mt-2">
            Principals & Studio Directors
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {TEAM_MEMBERS.map((member) => (
            <div
              key={member.id}
              className="group bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 overflow-hidden cursor-pointer"
              onClick={() => setSelectedTeamMember(member)}
            >
              <div className="h-72 overflow-hidden bg-stone-800">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 grayscale group-hover:grayscale-0"
                />
              </div>
              <div className="p-5">
                <p className="text-[10px] uppercase font-mono tracking-widest text-stone-400 mb-1">
                  {member.office}
                </p>
                <h3 className="text-lg font-serif text-stone-900 dark:text-stone-100 font-medium">
                  {member.name}
                </h3>
                <p className="text-xs text-amber-800 dark:text-amber-400 font-sans mt-0.5 mb-3">
                  {member.role}
                </p>
                <p className="text-xs text-stone-500 font-light line-clamp-3">
                  {member.bio}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Awards & Recognition Table */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.25em] text-amber-700 dark:text-amber-400 flex items-center space-x-1.5">
              <Award className="w-4 h-4" />
              <span>Accolades & Honors</span>
            </span>
            <h2 className="text-3xl font-serif font-light text-stone-900 dark:text-stone-100 mt-1">
              Awards Archive
            </h2>
          </div>
          <input
            type="text"
            value={awardSearch}
            onChange={(e) => setAwardSearch(e.target.value)}
            placeholder="Search awards by year, project, organization..."
            className="bg-stone-100 dark:bg-stone-900 border border-stone-300 dark:border-stone-700 px-3 py-2 text-xs text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none w-full sm:w-72"
          />
        </div>

        <div className="overflow-x-auto border border-stone-200 dark:border-stone-800">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-stone-100 dark:bg-stone-900 border-b border-stone-200 dark:border-stone-800 text-stone-500 font-mono uppercase tracking-widest">
                <th className="py-3 px-4 font-normal">Year</th>
                <th className="py-3 px-4 font-normal">Honor / Award Title</th>
                <th className="py-3 px-4 font-normal">Project</th>
                <th className="py-3 px-4 font-normal">Organization</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200 dark:divide-stone-800 font-light text-stone-700 dark:text-stone-300">
              {filteredAwards.map((item, idx) => (
                <tr key={idx} className="hover:bg-stone-100/50 dark:hover:bg-stone-900/50">
                  <td className="py-3.5 px-4 font-mono font-medium text-stone-900 dark:text-stone-100">
                    {item.year}
                  </td>
                  <td className="py-3.5 px-4 font-serif text-sm text-stone-900 dark:text-stone-100">
                    {item.award}
                  </td>
                  <td className="py-3.5 px-4 text-amber-800 dark:text-amber-400 font-sans">
                    {item.project}
                  </td>
                  <td className="py-3.5 px-4 text-stone-500 font-mono">
                    {item.organization}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Team Member Bio Modal */}
      {selectedTeamMember && (
        <div className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-800 text-stone-100 max-w-lg w-full p-8 relative">
            <button
              onClick={() => setSelectedTeamMember(null)}
              className="absolute top-4 right-4 text-stone-400 hover:text-white"
            >
              ✕
            </button>
            <div className="flex items-center space-x-4 mb-6">
              <img
                src={selectedTeamMember.image}
                alt={selectedTeamMember.name}
                className="w-20 h-20 rounded-full object-cover border border-stone-700"
              />
              <div>
                <h3 className="text-2xl font-serif text-white">{selectedTeamMember.name}</h3>
                <p className="text-xs text-amber-400 font-mono uppercase">{selectedTeamMember.role}</p>
                <p className="text-[10px] text-stone-400 uppercase font-mono">{selectedTeamMember.office}</p>
              </div>
            </div>
            <p className="text-sm text-stone-300 font-light leading-relaxed">
              {selectedTeamMember.bio}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
