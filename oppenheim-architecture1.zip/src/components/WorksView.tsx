import React, { useState, useMemo } from "react";
import { Project, ProjectCategory, ViewMode } from "../types";
import { ProjectCard } from "./ProjectCard";
import {
  Grid2X2,
  Grid3X3,
  LayoutGrid,
  List,
  Maximize2,
  Heart,
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  Filter,
  Search,
  Sparkles
} from "lucide-react";

interface WorksViewProps {
  projects: Project[];
  onSelectProject: (project: Project) => void;
  shortlist: string[];
  onToggleShortlist: (projectId: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: ProjectCategory;
  setSelectedCategory: (category: ProjectCategory) => void;
  onOpenAiConsultant: () => void;
}

export const WorksView: React.FC<WorksViewProps> = ({
  projects,
  onSelectProject,
  shortlist,
  onToggleShortlist,
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  onOpenAiConsultant,
}) => {
  const [viewMode, setViewMode] = useState<ViewMode>("grid-3");
  const [sortBy, setSortBy] = useState<"featured" | "year-desc" | "name-asc" | "category">("featured");
  const [activeSlideIndex, setActiveSlideIndex] = useState(0);

  const categories: ProjectCategory[] = [
    "All",
    "Hospitality",
    "Residential",
    "Commercial & Mixed-Use",
    "Cultural & Civic",
    "Masterplanning",
    "Interior Design",
  ];

  // Filter projects by category and search query
  const filteredProjects = useMemo(() => {
    return projects.filter((project) => {
      const matchesCategory =
        selectedCategory === "All" || project.category === selectedCategory;

      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        project.title.toLowerCase().includes(q) ||
        project.subtitle.toLowerCase().includes(q) ||
        project.location.toLowerCase().includes(q) ||
        project.category.toLowerCase().includes(q) ||
        project.materials.some((m) => m.toLowerCase().includes(q)) ||
        project.description.toLowerCase().includes(q);

      return matchesCategory && matchesSearch;
    });
  }, [projects, selectedCategory, searchQuery]);

  // Sort projects
  const sortedProjects = useMemo(() => {
    const copy = [...filteredProjects];
    if (sortBy === "year-desc") {
      return copy.sort((a, b) => Number(b.year) - Number(a.year));
    }
    if (sortBy === "name-asc") {
      return copy.sort((a, b) => a.title.localeCompare(b.title));
    }
    if (sortBy === "category") {
      return copy.sort((a, b) => a.category.localeCompare(b.category));
    }
    // Default: featured first
    return copy.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
  }, [filteredProjects, sortBy]);

  const activeSliderProject = sortedProjects[activeSlideIndex] || sortedProjects[0];

  const handlePrevSlide = () => {
    setActiveSlideIndex((prev) => (prev === 0 ? sortedProjects.length - 1 : prev - 1));
  };

  const handleNextSlide = () => {
    setActiveSlideIndex((prev) => (prev === sortedProjects.length - 1 ? 0 : prev + 1));
  };

  return (
    <div id="works-page-container" className="pt-24 pb-20 min-h-screen">
      {/* Category Navigation Bar & Toolbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b border-stone-200 dark:border-stone-800 pb-6">
          {/* Categories */}
          <div className="flex items-center space-x-1 sm:space-x-2 overflow-x-auto no-scrollbar py-1">
            {categories.map((cat) => (
              <button
                key={cat}
                id={`cat-filter-${cat.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 sm:px-4 py-2 rounded-full text-xs uppercase tracking-[0.15em] font-medium whitespace-nowrap transition-all focus:outline-none ${
                  selectedCategory === cat
                    ? "bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 shadow-xs"
                    : "text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-200/50 dark:hover:bg-stone-800/50"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Controls Right */}
          <div className="flex items-center justify-between lg:justify-end space-x-4">
            {/* Sort Selector */}
            <div className="flex items-center space-x-2 text-xs">
              <span className="text-stone-400 uppercase tracking-wider hidden sm:inline">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-stone-100 dark:bg-stone-900 text-stone-800 dark:text-stone-200 border border-stone-300 dark:border-stone-700 text-xs rounded-none px-2.5 py-1.5 uppercase tracking-wider focus:outline-none"
              >
                <option value="featured">Featured Works</option>
                <option value="year-desc">Year (Newest)</option>
                <option value="name-asc">Title (A-Z)</option>
                <option value="category">Typology</option>
              </select>
            </div>

            {/* View Mode Switcher */}
            <div className="flex items-center space-x-1 bg-stone-200/70 dark:bg-stone-800/70 p-1 rounded-md">
              <button
                onClick={() => setViewMode("grid-2")}
                className={`p-1.5 rounded transition-colors ${
                  viewMode === "grid-2"
                    ? "bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 shadow-xs"
                    : "text-stone-500 hover:text-stone-900 dark:hover:text-stone-100"
                }`}
                title="2 Columns"
                aria-label="2 Columns Grid"
              >
                <Grid2X2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("grid-3")}
                className={`p-1.5 rounded transition-colors hidden sm:block ${
                  viewMode === "grid-3"
                    ? "bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 shadow-xs"
                    : "text-stone-500 hover:text-stone-900 dark:hover:text-stone-100"
                }`}
                title="3 Columns"
                aria-label="3 Columns Grid"
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("grid-4")}
                className={`p-1.5 rounded transition-colors hidden lg:block ${
                  viewMode === "grid-4"
                    ? "bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 shadow-xs"
                    : "text-stone-500 hover:text-stone-900 dark:hover:text-stone-100"
                }`}
                title="4 Columns"
                aria-label="4 Columns Grid"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-1.5 rounded transition-colors ${
                  viewMode === "list"
                    ? "bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 shadow-xs"
                    : "text-stone-500 hover:text-stone-900 dark:hover:text-stone-100"
                }`}
                title="List Index"
                aria-label="List View"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("fullscreen")}
                className={`p-1.5 rounded transition-colors ${
                  viewMode === "fullscreen"
                    ? "bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 shadow-xs"
                    : "text-stone-500 hover:text-stone-900 dark:hover:text-stone-100"
                }`}
                title="Fullscreen Showcase Slider"
                aria-label="Fullscreen Slider"
              >
                <Maximize2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Counter & Search Status */}
        <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400 font-mono mb-6">
          <span className="uppercase tracking-widest">
            Showing {sortedProjects.length} of {projects.length} Works
            {selectedCategory !== "All" && ` • ${selectedCategory}`}
            {searchQuery && ` • Search: "${searchQuery}"`}
          </span>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="text-stone-800 dark:text-stone-200 underline uppercase tracking-wider"
            >
              Reset Search
            </button>
          )}
        </div>
      </div>

      {/* NO RESULTS STATE */}
      {sortedProjects.length === 0 && (
        <div className="max-w-xl mx-auto text-center py-24 px-4">
          <Filter className="w-10 h-10 mx-auto text-stone-400 mb-4 stroke-1" />
          <h3 className="text-lg font-serif tracking-wide text-stone-800 dark:text-stone-200 mb-2">
            No Architectural Works Match Criteria
          </h3>
          <p className="text-xs text-stone-500 mb-6 font-light">
            Try resetting your active category filter or clearing your search input.
          </p>
          <button
            onClick={() => {
              setSelectedCategory("All");
              setSearchQuery("");
            }}
            className="px-5 py-2 bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 text-xs uppercase tracking-widest"
          >
            Show All Works
          </button>
        </div>
      )}

      {/* FULLSCREEN SLIDER MODE */}
      {viewMode === "fullscreen" && sortedProjects.length > 0 && activeSliderProject && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative h-[70vh] sm:h-[80vh] w-full overflow-hidden rounded-none border border-stone-300 dark:border-stone-800 group bg-stone-950">
            {/* Slide Background Image */}
            <img
              src={activeSliderProject.heroImage}
              alt={activeSliderProject.title}
              className="w-full h-full object-cover opacity-90 transition-transform duration-1000 ease-out group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />

            {/* Slide Text Content */}
            <div className="absolute bottom-0 left-0 right-0 p-8 sm:p-12 text-white flex flex-col justify-end max-w-4xl">
              <div className="flex items-center space-x-3 mb-3 text-xs uppercase tracking-[0.25em] text-stone-300">
                <span className="px-2.5 py-0.5 bg-stone-100/20 backdrop-blur-md rounded-none text-[10px] font-mono">
                  {activeSliderProject.category}
                </span>
                <span>• {activeSliderProject.location}</span>
                <span>• {activeSliderProject.year}</span>
              </div>
              <h2 className="text-3xl sm:text-5xl font-serif font-light tracking-wide mb-3 leading-tight">
                {activeSliderProject.title}
              </h2>
              <p className="text-sm sm:text-base text-stone-300 font-light mb-6 line-clamp-2 max-w-2xl">
                {activeSliderProject.subtitle || activeSliderProject.description}
              </p>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => onSelectProject(activeSliderProject)}
                  className="inline-flex items-center space-x-2 px-6 py-3 bg-stone-100 text-stone-900 hover:bg-white text-xs uppercase tracking-[0.2em] font-semibold transition-all shadow-md"
                >
                  <span>Explore Project</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onToggleShortlist(activeSliderProject.id)}
                  className={`p-3 border border-stone-600 hover:border-stone-300 transition-colors ${
                    shortlist.includes(activeSliderProject.id) ? "bg-red-600/80 text-white border-red-500" : "text-stone-300"
                  }`}
                  title="Bookmark to shortlist"
                >
                  <Heart className={`w-4 h-4 ${shortlist.includes(activeSliderProject.id) ? "fill-white" : ""}`} />
                </button>
              </div>
            </div>

            {/* Slider Navigation Arrows */}
            <div className="absolute top-1/2 -translate-y-1/2 left-4 right-4 flex justify-between pointer-events-none">
              <button
                onClick={handlePrevSlide}
                className="pointer-events-auto p-3 bg-stone-950/60 hover:bg-stone-950/90 text-white rounded-full backdrop-blur-md transition-all transform hover:-translate-x-1"
                aria-label="Previous Slide"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={handleNextSlide}
                className="pointer-events-auto p-3 bg-stone-950/60 hover:bg-stone-950/90 text-white rounded-full backdrop-blur-md transition-all transform hover:translate-x-1"
                aria-label="Next Slide"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            {/* Slider Pagination Indicators */}
            <div className="absolute bottom-6 right-8 flex items-center space-x-2 text-xs font-mono text-white">
              <span>{String(activeSlideIndex + 1).padStart(2, "0")}</span>
              <span className="text-stone-500">/</span>
              <span className="text-stone-400">{String(sortedProjects.length).padStart(2, "0")}</span>
            </div>
          </div>
        </div>
      )}

      {/* LIST INDEX MODE */}
      {viewMode === "list" && sortedProjects.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="overflow-x-auto border border-stone-200 dark:border-stone-800">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-stone-100 dark:bg-stone-900/80 border-b border-stone-200 dark:border-stone-800 text-stone-500 uppercase tracking-[0.2em] font-mono">
                  <th className="py-3.5 px-4 font-normal">Preview</th>
                  <th className="py-3.5 px-4 font-normal">Project Title</th>
                  <th className="py-3.5 px-4 font-normal hidden sm:table-cell">Typology</th>
                  <th className="py-3.5 px-4 font-normal">Location</th>
                  <th className="py-3.5 px-4 font-normal hidden md:table-cell">Year</th>
                  <th className="py-3.5 px-4 font-normal hidden lg:table-cell">Status</th>
                  <th className="py-3.5 px-4 font-normal text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200 dark:divide-stone-800">
                {sortedProjects.map((project) => (
                  <tr
                    key={project.id}
                    className="hover:bg-stone-100/60 dark:hover:bg-stone-900/60 transition-colors group cursor-pointer"
                    onClick={() => onSelectProject(project)}
                  >
                    <td className="py-3 px-4 w-16">
                      <img
                        src={project.heroImage}
                        alt={project.title}
                        className="w-12 h-10 object-cover rounded-none border border-stone-300 dark:border-stone-700"
                      />
                    </td>
                    <td className="py-3 px-4 font-serif text-sm text-stone-900 dark:text-stone-100 group-hover:text-amber-700 dark:group-hover:text-amber-400 font-medium">
                      {project.title}
                      {project.featured && (
                        <span className="ml-2 inline-block px-1.5 py-0.2 text-[9px] uppercase tracking-widest bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 rounded-none">
                          Featured
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 hidden sm:table-cell text-stone-600 dark:text-stone-400 font-sans">
                      {project.category}
                    </td>
                    <td className="py-3 px-4 text-stone-600 dark:text-stone-400 font-sans">
                      {project.location}
                    </td>
                    <td className="py-3 px-4 hidden md:table-cell text-stone-500 font-mono">
                      {project.year}
                    </td>
                    <td className="py-3 px-4 hidden lg:table-cell">
                      <span className="px-2 py-0.5 text-[10px] uppercase font-mono tracking-wider bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300">
                        {project.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end space-x-2" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => onToggleShortlist(project.id)}
                          className="p-1.5 text-stone-400 hover:text-red-500"
                          title="Shortlist"
                        >
                          <Heart className={`w-3.5 h-3.5 ${shortlist.includes(project.id) ? "fill-red-500 text-red-500" : ""}`} />
                        </button>
                        <button
                          onClick={() => onSelectProject(project)}
                          className="p-1.5 text-stone-700 dark:text-stone-300 hover:text-stone-950 dark:hover:text-stone-100"
                          title="View Details"
                        >
                          <ArrowUpRight className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* GRID MODES (2, 3, OR 4 COLUMNS) */}
      {viewMode !== "list" && viewMode !== "fullscreen" && sortedProjects.length > 0 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className={`grid gap-6 sm:gap-8 ${
              viewMode === "grid-2"
                ? "grid-cols-1 md:grid-cols-2"
                : viewMode === "grid-4"
                ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
                : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
            }`}
          >
            {sortedProjects.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                onSelectProject={onSelectProject}
                isShortlisted={shortlist.includes(project.id)}
                onToggleShortlist={onToggleShortlist}
                viewMode={viewMode}
              />
            ))}
          </div>
        </div>
      )}

      {/* Floating AI Studio Banner at bottom of Works Page */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="bg-stone-900 dark:bg-stone-900 border border-stone-800 p-8 sm:p-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-amber-400 text-xs font-mono uppercase tracking-widest mb-2">
              <Sparkles className="w-4 h-4" />
              <span>Oppenheim AI Architectural Consultant</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-serif text-stone-100 font-light">
              Looking for custom site analysis or material recommendations?
            </h3>
            <p className="text-xs text-stone-400 font-light mt-1 max-w-2xl">
              Ask our server-side AI assistant trained on Oppenheim's 25-year portfolio, material palettes, and "Design Following Life" philosophy.
            </p>
          </div>
          <button
            onClick={onOpenAiConsultant}
            className="px-6 py-3 bg-stone-100 text-stone-900 hover:bg-white text-xs uppercase tracking-[0.2em] font-semibold transition-colors shrink-0 shadow-sm"
          >
            Launch AI Assistant
          </button>
        </div>
      </div>
    </div>
  );
};
