import React, { useState, useEffect } from "react";
import { ActivePage } from "../types";
import { Search, Heart, Moon, Sun, Menu, X, Sparkles } from "lucide-react";

interface HeaderProps {
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  shortlistCount: number;
  onOpenShortlist: () => void;
  onOpenAiConsultant: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activePage,
  setActivePage,
  shortlistCount,
  onOpenShortlist,
  onOpenAiConsultant,
  searchQuery,
  setSearchQuery,
  darkMode,
  setDarkMode,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems: { id: ActivePage; label: string }[] = [
    { id: "works", label: "Works" },
    { id: "studio", label: "Studio" },
    { id: "news", label: "News" },
    { id: "publications", label: "Publications" },
    { id: "contact", label: "Contact" },
  ];

  const handleNavClick = (page: ActivePage) => {
    setActivePage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <>
      <header
        id="main-header"
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled
            ? "bg-stone-50/90 dark:bg-stone-950/90 backdrop-blur-md py-3 shadow-sm border-b border-stone-200/50 dark:border-stone-800/50"
            : "bg-transparent py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo */}
          <button
            id="brand-logo-btn"
            onClick={() => handleNavClick("works")}
            className="group flex flex-col text-left focus:outline-none"
            aria-label="Oppenheim Architecture Home"
          >
            <span className="text-base sm:text-lg tracking-[0.25em] font-serif font-semibold text-stone-900 dark:text-stone-100 group-hover:opacity-80 transition-opacity">
              OPPENHEIM
            </span>
            <span className="text-[10px] tracking-[0.35em] uppercase text-stone-500 dark:text-stone-400 font-sans font-medium -mt-0.5">
              ARCHITECTURE
            </span>
          </button>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`text-xs uppercase tracking-[0.2em] font-medium transition-colors relative py-1 focus:outline-none ${
                  activePage === item.id
                    ? "text-stone-950 dark:text-stone-50 font-semibold"
                    : "text-stone-600 hover:text-stone-950 dark:text-stone-400 dark:hover:text-stone-100"
                }`}
              >
                {item.label}
                {activePage === item.id && (
                  <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-stone-900 dark:bg-stone-100 transition-all" />
                )}
              </button>
            ))}
          </nav>

          {/* Action Controls */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            {/* Search Toggle */}
            <button
              id="search-toggle-btn"
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 rounded-full text-stone-700 hover:text-stone-950 dark:text-stone-300 dark:hover:text-stone-100 hover:bg-stone-200/50 dark:hover:bg-stone-800/50 transition-colors"
              title="Search works"
              aria-label="Search"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* AI Assistant Button */}
            <button
              id="ai-consultant-btn"
              onClick={onOpenAiConsultant}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-[11px] uppercase tracking-widest font-medium bg-stone-900 text-stone-50 hover:bg-stone-800 dark:bg-stone-100 dark:text-stone-900 dark:hover:bg-stone-200 transition-colors shadow-xs"
              title="Ask AI Architecture Assistant"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400 dark:text-amber-600" />
              <span className="hidden sm:inline">AI Studio</span>
            </button>

            {/* Saved Shortlist / Favorites */}
            <button
              id="shortlist-btn"
              onClick={onOpenShortlist}
              className="relative p-2 rounded-full text-stone-700 hover:text-stone-950 dark:text-stone-300 dark:hover:text-stone-100 hover:bg-stone-200/50 dark:hover:bg-stone-800/50 transition-colors"
              title="View Shortlist"
              aria-label={`Shortlist (${shortlistCount} saved)`}
            >
              <Heart className={`w-4 h-4 ${shortlistCount > 0 ? "fill-red-500 text-red-500" : ""}`} />
              {shortlistCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-red-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {shortlistCount}
                </span>
              )}
            </button>

            {/* Dark Mode Toggle */}
            <button
              id="theme-toggle-btn"
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-full text-stone-700 hover:text-stone-950 dark:text-stone-300 dark:hover:text-stone-100 hover:bg-stone-200/50 dark:hover:bg-stone-800/50 transition-colors"
              title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
              aria-label="Toggle Theme"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-stone-700" />}
            </button>

            {/* Mobile Hamburger Menu Toggle */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-full text-stone-800 dark:text-stone-200 hover:bg-stone-200/50 dark:hover:bg-stone-800/50"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Quick Search Dropdown Bar */}
        {searchOpen && (
          <div
            id="search-dropdown"
            className="w-full bg-stone-100/95 dark:bg-stone-900/95 border-b border-stone-200 dark:border-stone-800 px-4 py-3 shadow-md"
          >
            <div className="max-w-3xl mx-auto flex items-center space-x-3">
              <Search className="w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (activePage !== "works") {
                    setActivePage("works");
                  }
                }}
                placeholder="Search works by location, title, material, category (e.g. Desert Rock, Jordan, Concrete)..."
                className="w-full bg-transparent text-sm text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none"
                autoFocus
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="text-xs text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 uppercase tracking-wider"
                >
                  Clear
                </button>
              )}
              <button
                onClick={() => setSearchOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Mobile Menu Drawer Overlay */}
      {mobileMenuOpen && (
        <div id="mobile-menu-overlay" className="fixed inset-0 z-30 bg-stone-950/90 backdrop-blur-md md:hidden flex flex-col justify-center px-8 py-16">
          <div className="flex justify-between items-center mb-12">
            <span className="text-xs uppercase tracking-[0.3em] text-stone-400">Navigation</span>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 text-stone-300 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <nav className="flex flex-col space-y-6">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`text-2xl font-serif tracking-widest text-left transition-colors ${
                  activePage === item.id
                    ? "text-stone-50 font-bold border-l-2 border-amber-400 pl-4"
                    : "text-stone-400 hover:text-stone-100 pl-4"
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
          <div className="mt-16 pt-8 border-t border-stone-800 flex items-center justify-between text-xs text-stone-400 uppercase tracking-widest">
            <span>Oppenheim Architecture</span>
            <span>Miami • Basel • NYC</span>
          </div>
        </div>
      )}
    </>
  );
};
