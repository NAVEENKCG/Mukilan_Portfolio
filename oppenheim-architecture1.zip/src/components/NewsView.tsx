import React, { useState } from "react";
import { NEWS_ARTICLES } from "../data/newsData";
import { NewsArticle } from "../types";
import { BookOpen, Clock, ArrowUpRight, X, Sparkles } from "lucide-react";

export const NewsView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [activeArticle, setActiveArticle] = useState<NewsArticle | null>(null);

  const categories = ["All", "Press Release", "Award", "Publication", "Lecture", "Feature"];

  const filteredArticles = NEWS_ARTICLES.filter(
    (art) => selectedCategory === "All" || art.category === selectedCategory
  );

  return (
    <div id="news-page-container" className="pt-24 pb-20 min-h-screen">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="border-b border-stone-200 dark:border-stone-800 pb-8">
          <p className="text-xs uppercase tracking-[0.35em] text-stone-500 font-mono mb-2">
            Dispatches & Press
          </p>
          <h1 className="text-4xl sm:text-6xl font-serif font-light text-stone-900 dark:text-stone-50 tracking-wide">
            News & Media Coverage
          </h1>
        </div>

        {/* Categories */}
        <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar py-4 mt-4">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 text-xs uppercase tracking-widest font-mono whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? "bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900"
                  : "text-stone-500 hover:text-stone-900 dark:hover:text-stone-100"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Articles Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredArticles.map((article) => (
            <div
              key={article.id}
              className="bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 overflow-hidden group cursor-pointer flex flex-col justify-between"
              onClick={() => setActiveArticle(article)}
            >
              <div className="h-64 overflow-hidden relative bg-stone-900">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute top-3 left-3 bg-stone-950/80 px-2.5 py-1 text-[10px] font-mono text-stone-200 uppercase tracking-widest">
                  {article.category}
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-stone-400 font-mono mb-2">
                    <span>{article.date}</span>
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{article.readTime}</span>
                    </span>
                  </div>
                  <h3 className="text-xl font-serif text-stone-900 dark:text-stone-100 group-hover:text-amber-800 dark:group-hover:text-amber-400 transition-colors leading-snug mb-3">
                    {article.title}
                  </h3>
                  <p className="text-xs text-stone-600 dark:text-stone-400 font-light leading-relaxed mb-4">
                    {article.summary}
                  </p>
                </div>
                <div className="pt-4 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between text-xs font-mono uppercase tracking-widest text-stone-500 group-hover:text-stone-900 dark:group-hover:text-stone-100">
                  <span>Published in {article.publication}</span>
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Article Reader Modal */}
      {activeArticle && (
        <div className="fixed inset-0 z-50 bg-stone-950/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-stone-900 border border-stone-800 text-stone-100 max-w-2xl w-full p-8 my-8 relative">
            <button
              onClick={() => setActiveArticle(null)}
              className="absolute top-4 right-4 p-2 text-stone-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="text-xs font-mono text-amber-400 uppercase tracking-widest mb-2">
              {activeArticle.category} • {activeArticle.date}
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif text-white mb-4 leading-snug">
              {activeArticle.title}
            </h2>
            <img
              src={activeArticle.image}
              alt={activeArticle.title}
              className="w-full h-64 object-cover mb-6 border border-stone-800"
            />
            <p className="text-sm text-stone-300 font-light leading-relaxed mb-6">
              {activeArticle.content}
            </p>
            <div className="pt-4 border-t border-stone-800 flex items-center justify-between text-xs font-mono text-stone-400">
              <span>Source: {activeArticle.publication}</span>
              <button
                onClick={() => setActiveArticle(null)}
                className="px-4 py-2 bg-stone-100 text-stone-900 uppercase font-semibold text-[10px] tracking-widest"
              >
                Close Article
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
