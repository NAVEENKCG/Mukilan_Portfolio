import React, { useState } from "react";
import { OFFICES, CAREER_ROLES } from "../data/studioData";
import { StudioOffice, CareerRole } from "../types";
import { MapPin, Phone, Mail, Clock, CheckCircle, Send, Briefcase } from "lucide-react";

export const ContactView: React.FC = () => {
  const [selectedOffice, setSelectedOffice] = useState<StudioOffice>(OFFICES[0]);
  const [inquiryType, setInquiryType] = useState<"project" | "press" | "general">("project");
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    location: "",
    budget: "$1M - $5M",
    message: "",
  });

  const [selectedRole, setSelectedRole] = useState<CareerRole | null>(null);
  const [jobApplied, setJobApplied] = useState(false);

  const handleSubmitInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email) {
      setFormSubmitted(true);
      setTimeout(() => {
        setFormSubmitted(false);
        setFormData({
          name: "",
          email: "",
          phone: "",
          location: "",
          budget: "$1M - $5M",
          message: "",
        });
      }, 5000);
    }
  };

  return (
    <div id="contact-page-container" className="pt-24 pb-20 min-h-screen">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="border-b border-stone-200 dark:border-stone-800 pb-8">
          <p className="text-xs uppercase tracking-[0.35em] text-stone-500 font-mono mb-2">
            Inquiries & Representation
          </p>
          <h1 className="text-4xl sm:text-6xl font-serif font-light text-stone-900 dark:text-stone-50 tracking-wide">
            Contact & Global Studios
          </h1>
        </div>
      </div>

      {/* Office Switcher & Map Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Office Selection List */}
          <div className="space-y-4">
            <p className="text-xs font-mono uppercase tracking-[0.25em] text-amber-800 dark:text-amber-400">
              Select Studio Location
            </p>
            <div className="space-y-3">
              {OFFICES.map((office) => (
                <button
                  key={office.id}
                  onClick={() => setSelectedOffice(office)}
                  className={`w-full text-left p-5 border transition-all ${
                    selectedOffice.id === office.id
                      ? "bg-stone-900 text-stone-100 border-stone-800 shadow-md"
                      : "bg-stone-100 dark:bg-stone-900/60 text-stone-900 dark:text-stone-200 border-stone-200 dark:border-stone-800 hover:border-stone-400"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-lg font-serif">{office.city} Studio</span>
                    <span className="text-[10px] font-mono uppercase text-amber-400">{office.country}</span>
                  </div>
                  <p className="text-xs font-light opacity-80">{office.address}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Active Office Details & Map Box */}
          <div className="lg:col-span-2 bg-stone-900 text-stone-100 border border-stone-800 p-8 flex flex-col justify-between">
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-stone-800 pb-4 mb-6 gap-2">
                <div>
                  <h3 className="text-2xl font-serif text-white">{selectedOffice.city} Headquarters</h3>
                  <p className="text-xs font-mono text-stone-400">Studio Manager: {selectedOffice.manager}</p>
                </div>
                <div className="text-right text-xs font-mono text-amber-400">
                  {selectedOffice.timezone}
                </div>
              </div>

              {/* Coordinates Preview Canvas Box */}
              <div className="relative h-64 bg-stone-950 border border-stone-800 overflow-hidden mb-6 flex items-center justify-center">
                <img
                  src={selectedOffice.image}
                  alt={selectedOffice.city}
                  className="w-full h-full object-cover opacity-50"
                />
                <div className="absolute inset-0 bg-stone-950/40" />
                <div className="relative text-center p-4">
                  <MapPin className="w-8 h-8 text-amber-400 mx-auto mb-2 animate-bounce" />
                  <p className="text-sm font-serif text-white font-medium">{selectedOffice.city} Studio</p>
                  <p className="text-xs font-mono text-stone-300">{selectedOffice.address}</p>
                  <p className="text-[10px] font-mono text-stone-400 mt-1">
                    LAT {selectedOffice.coordinates.lat}° N / LNG {selectedOffice.coordinates.lng}° W
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono text-stone-300">
                <div className="flex items-center space-x-2 p-3 bg-stone-950 border border-stone-800">
                  <Phone className="w-4 h-4 text-amber-400" />
                  <span>{selectedOffice.phone}</span>
                </div>
                <div className="flex items-center space-x-2 p-3 bg-stone-950 border border-stone-800">
                  <Mail className="w-4 h-4 text-amber-400" />
                  <span>{selectedOffice.email}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Project Inquiry Form */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-24">
        <div className="bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-8 sm:p-12">
          <div className="max-w-2xl mb-8">
            <p className="text-xs font-mono uppercase tracking-[0.25em] text-amber-800 dark:text-amber-400 mb-2">
              Commission & Press Inquiries
            </p>
            <h2 className="text-3xl font-serif text-stone-900 dark:text-stone-100">
              Initiate a Design Dialogue
            </h2>
          </div>

          <div className="flex space-x-4 mb-8">
            <button
              onClick={() => setInquiryType("project")}
              className={`px-4 py-2 text-xs uppercase font-mono tracking-wider border transition-colors ${
                inquiryType === "project"
                  ? "bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900 border-transparent"
                  : "border-stone-300 dark:border-stone-700 text-stone-600 dark:text-stone-400"
              }`}
            >
              New Architecture Commission
            </button>
            <button
              onClick={() => setInquiryType("press")}
              className={`px-4 py-2 text-xs uppercase font-mono tracking-wider border transition-colors ${
                inquiryType === "press"
                  ? "bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900 border-transparent"
                  : "border-stone-300 dark:border-stone-700 text-stone-600 dark:text-stone-400"
              }`}
            >
              Press & Media Requests
            </button>
          </div>

          {formSubmitted ? (
            <div className="p-8 bg-emerald-950/40 border border-emerald-800 text-emerald-200 flex items-center space-x-4">
              <CheckCircle className="w-8 h-8 text-emerald-400 shrink-0" />
              <div>
                <h4 className="text-lg font-serif">Inquiry Successfully Transmitted</h4>
                <p className="text-xs font-light text-emerald-300">
                  Our principal directors will review your parameters and respond within 48 hours.
                </p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmitInquiry} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-stone-500 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Lorde Sterling"
                    className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-700 px-4 py-3 text-sm text-stone-900 dark:text-stone-100 focus:outline-none focus:border-stone-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-stone-500 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="sterling@estate.com"
                    className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-700 px-4 py-3 text-sm text-stone-900 dark:text-stone-100 focus:outline-none focus:border-stone-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-stone-500 mb-2">
                    Project Location / Site Context
                  </label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="e.g. Kyoto, Japan or Aspen, Colorado"
                    className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-700 px-4 py-3 text-sm text-stone-900 dark:text-stone-100 focus:outline-none focus:border-stone-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-stone-500 mb-2">
                    Estimated Construction Budget
                  </label>
                  <select
                    value={formData.budget}
                    onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                    className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-700 px-4 py-3 text-sm text-stone-900 dark:text-stone-100 focus:outline-none"
                  >
                    <option>$1M - $5M</option>
                    <option>$5M - $15M</option>
                    <option>$15M - $50M</option>
                    <option>$50M+</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-stone-500 mb-2">
                  Project Brief & Vision *
                </label>
                <textarea
                  rows={5}
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Describe your site parameters, typology requirements, or vision..."
                  className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-300 dark:border-stone-700 px-4 py-3 text-sm text-stone-900 dark:text-stone-100 focus:outline-none focus:border-stone-500"
                />
              </div>

              <button
                type="submit"
                className="px-8 py-4 bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 text-xs font-mono font-semibold uppercase tracking-[0.2em] hover:opacity-90 transition-opacity flex items-center space-x-2"
              >
                <span>Transmit Design Inquiry</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Careers Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="border-t border-stone-200 dark:border-stone-800 pt-16">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
            <div>
              <span className="text-xs font-mono uppercase tracking-[0.25em] text-amber-800 dark:text-amber-400 flex items-center space-x-1.5">
                <Briefcase className="w-4 h-4" />
                <span>Careers at Oppenheim</span>
              </span>
              <h2 className="text-3xl font-serif text-stone-900 dark:text-stone-100 mt-1">
                Open Studio Positions
              </h2>
            </div>
            <p className="text-xs text-stone-500 max-w-md font-light mt-2 md:mt-0">
              We seek architects passionate about elemental materiality, site analysis, and precise digital modeling.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {CAREER_ROLES.map((role) => (
              <div
                key={role.id}
                className="bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-6 space-y-3"
              >
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-amber-800 dark:text-amber-400 uppercase">{role.office}</span>
                  <span className="text-stone-500">{role.type} • {role.experience}</span>
                </div>
                <h3 className="text-xl font-serif text-stone-900 dark:text-stone-100">{role.title}</h3>
                <p className="text-xs text-stone-600 dark:text-stone-400 font-light leading-relaxed">
                  {role.description}
                </p>
                <button
                  onClick={() => setSelectedRole(role)}
                  className="pt-2 text-xs font-mono text-stone-900 dark:text-stone-100 underline uppercase tracking-wider hover:text-amber-600"
                >
                  View Requirements & Apply
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Role Requirements Modal */}
      {selectedRole && (
        <div className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-800 text-stone-100 max-w-lg w-full p-8 relative">
            <button
              onClick={() => {
                setSelectedRole(null);
                setJobApplied(false);
              }}
              className="absolute top-4 right-4 text-stone-400 hover:text-white"
            >
              ✕
            </button>

            <span className="text-xs font-mono text-amber-400 uppercase">{selectedRole.office}</span>
            <h3 className="text-2xl font-serif text-white mb-2">{selectedRole.title}</h3>
            <p className="text-xs text-stone-400 mb-6 font-light">{selectedRole.description}</p>

            <h4 className="text-xs font-mono uppercase text-stone-300 mb-2">Qualifications:</h4>
            <ul className="space-y-2 text-xs text-stone-300 font-light mb-6 list-disc list-inside">
              {selectedRole.requirements.map((req, i) => (
                <li key={i}>{req}</li>
              ))}
            </ul>

            {jobApplied ? (
              <p className="p-3 bg-emerald-900/60 text-emerald-300 text-xs font-mono text-center">
                ✓ Application transmitted to {selectedRole.office} hiring director.
              </p>
            ) : (
              <button
                onClick={() => setJobApplied(true)}
                className="w-full py-3 bg-stone-100 text-stone-900 text-xs font-mono uppercase tracking-widest font-semibold hover:bg-white"
              >
                Submit Application Profile
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
