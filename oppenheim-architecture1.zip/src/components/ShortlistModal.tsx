import React from "react";
import { Project } from "../types";
import { X, Trash2, ArrowUpRight, Download, FileText, Heart } from "lucide-react";

interface ShortlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  shortlist: string[];
  allProjects: Project[];
  onRemoveFromShortlist: (id: string) => void;
  onClearShortlist: () => void;
  onSelectProject: (project: Project) => void;
}

export const ShortlistModal: React.FC<ShortlistModalProps> = ({
  isOpen,
  onClose,
  shortlist,
  allProjects,
  onRemoveFromShortlist,
  onClearShortlist,
  onSelectProject,
}) => {
  if (!isOpen) return null;

  const savedProjects = allProjects.filter((p) => shortlist.includes(p.id));

  const handleExportPDF = () => {
    const textContent = `OPPENHEIM ARCHITECTURE - CURATED SHORTLIST COLLECTION\n` +
      `Date: ${new Date().toLocaleDateString()}\n\n` +
      savedProjects
        .map(
          (p, i) =>
            `${i + 1}. ${p.title} (${p.year})\n   Category: ${p.category}\n   Location: ${p.location}\n   Area: ${p.area}\n   Summary: ${p.subtitle || p.description}\n`
        )
        .join("\n");

    const element = document.createElement("a");
    const file = new Blob([textContent], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `Oppenheim_Architecture_Curated_Shortlist.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-md flex justify-end">
      <div className="bg-stone-50 dark:bg-stone-900 border-l border-stone-200 dark:border-stone-800 text-stone-900 dark:text-stone-100 w-full max-w-xl h-full flex flex-col justify-between p-6 sm:p-8">
        {/* Header */}
        <div>
          <div className="flex items-center justify-between border-b border-stone-200 dark:border-stone-800 pb-4 mb-6">
            <div className="flex items-center space-x-2">
              <Heart className="w-5 h-5 text-red-500 fill-red-500" />
              <h2 className="text-xl font-serif text-stone-900 dark:text-white">Saved Shortlist</h2>
              <span className="text-xs font-mono text-stone-600 dark:text-stone-400 bg-stone-200 dark:bg-stone-800 px-2 py-0.5">
                {savedProjects.length} Works
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List of saved projects */}
          {savedProjects.length === 0 ? (
            <div className="py-20 text-center text-stone-500 dark:text-stone-400 space-y-3">
              <Heart className="w-12 h-12 mx-auto stroke-1 opacity-50" />
              <p className="text-sm font-serif">Your shortlist collection is empty.</p>
              <p className="text-xs font-light max-w-xs mx-auto">
                Click the heart icon on any architectural work in the portfolio to curate your personal collection.
              </p>
            </div>
          ) : (
            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2 no-scrollbar">
              {savedProjects.map((p) => (
                <div
                  key={p.id}
                  className="bg-white dark:bg-stone-950 border border-stone-200 dark:border-stone-800 p-4 flex items-center justify-between group hover:border-stone-400 dark:hover:border-stone-700 transition-colors cursor-pointer"
                  onClick={() => {
                    onSelectProject(p);
                    onClose();
                  }}
                >
                  <div className="flex items-center space-x-4">
                    <img
                      src={p.heroImage}
                      alt={p.title}
                      className="w-16 h-12 object-cover border border-stone-200 dark:border-stone-800"
                    />
                    <div>
                      <h4 className="text-sm font-serif text-stone-900 dark:text-white group-hover:text-amber-800 dark:group-hover:text-amber-400 transition-colors">
                        {p.title}
                      </h4>
                      <p className="text-[10px] font-mono text-stone-500 dark:text-stone-400">
                        {p.category} • {p.location} ({p.year})
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => onRemoveFromShortlist(p.id)}
                      className="p-2 text-stone-400 hover:text-red-500"
                      title="Remove from shortlist"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        onSelectProject(p);
                        onClose();
                      }}
                      className="p-2 text-stone-600 dark:text-stone-300 hover:text-stone-950 dark:hover:text-white"
                      title="Explore details"
                    >
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        {savedProjects.length > 0 && (
          <div className="border-t border-stone-200 dark:border-stone-800 pt-6 space-y-3">
            <button
              onClick={handleExportPDF}
              className="w-full py-3 bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 text-xs font-mono font-semibold uppercase tracking-widest hover:opacity-90 flex items-center justify-center space-x-2 shadow-xs"
            >
              <Download className="w-4 h-4" />
              <span>Export Shortlist Summary (.TXT)</span>
            </button>
            <button
              onClick={onClearShortlist}
              className="w-full py-2 text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-200 text-xs font-mono uppercase tracking-wider text-center"
            >
              Clear Entire Shortlist
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
