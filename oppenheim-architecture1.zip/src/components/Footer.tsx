import React, { useState } from "react";
import { ActivePage } from "../types";
import { ArrowUp, ArrowRight, Instagram, Linkedin, Globe, Mail } from "lucide-react";

interface FooterProps {
  setActivePage: (page: ActivePage) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActivePage }) => {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail("");
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer id="main-footer" className="bg-stone-900 text-stone-300 border-t border-stone-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8 mb-16">
          {/* Brand & Mission */}
          <div className="space-y-4">
            <div className="flex flex-col">
              <span className="text-xl tracking-[0.25em] font-serif font-bold text-stone-100">
                OPPENHEIM
              </span>
              <span className="text-xs tracking-[0.35em] uppercase text-stone-400 font-sans -mt-0.5">
                ARCHITECTURE
              </span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed font-light pr-4">
              Design Following Life. Form Following Feeling. Creating elemental, site-sensitive architectural monoliths across the globe.
            </p>
            <div className="pt-2 flex items-center space-x-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-full border border-stone-800 text-stone-400 hover:text-stone-100 hover:border-stone-600 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-full border border-stone-800 text-stone-400 hover:text-stone-100 hover:border-stone-600 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="https://archdaily.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-full border border-stone-800 text-stone-400 hover:text-stone-100 hover:border-stone-600 transition-colors"
                aria-label="ArchDaily"
              >
                <Globe className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Studio Offices */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-100">
              Studios
            </h4>
            <div className="space-y-3 text-xs text-stone-400 font-light">
              <div>
                <p className="font-medium text-stone-200">MIAMI</p>
                <p>2500 NW 2nd Ave, Suite 100</p>
                <p>Miami, FL 33127 • +1 (305) 573-2256</p>
              </div>
              <div>
                <p className="font-medium text-stone-200">BASEL / MUTTENZ</p>
                <p>Kirchplatz 14, 4132 Muttenz</p>
                <p>Switzerland • +41 61 463 88 00</p>
              </div>
              <div>
                <p className="font-medium text-stone-200">NEW YORK</p>
                <p>1123 Broadway, Suite 901</p>
                <p>New York, NY 10010 • +1 (212) 352-0900</p>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-100">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs uppercase tracking-widest text-stone-400 font-medium">
              <li>
                <button
                  onClick={() => {
                    setActivePage("works");
                    scrollToTop();
                  }}
                  className="hover:text-stone-100 transition-colors"
                >
                  Works & Projects
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActivePage("studio");
                    scrollToTop();
                  }}
                  className="hover:text-stone-100 transition-colors"
                >
                  Studio & Philosophy
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActivePage("news");
                    scrollToTop();
                  }}
                  className="hover:text-stone-100 transition-colors"
                >
                  News & Press
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActivePage("publications");
                    scrollToTop();
                  }}
                  className="hover:text-stone-100 transition-colors"
                >
                  Publications & Books
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActivePage("contact");
                    scrollToTop();
                  }}
                  className="hover:text-stone-100 transition-colors"
                >
                  Contact & Careers
                </button>
              </li>
            </ul>
          </div>

          {/* Monograph & Journal Dispatch */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-100">
              Journal Dispatch
            </h4>
            <p className="text-xs text-stone-400 font-light leading-relaxed">
              Receive curated architectural essays, monographs, and site excavation logs.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter email address"
                  className="w-full bg-stone-800 border border-stone-700 rounded-none px-3 py-2 text-xs text-stone-100 placeholder-stone-500 focus:outline-none focus:border-stone-400 pr-10"
                  required
                />
                <button
                  type="submit"
                  className="absolute right-0 top-0 bottom-0 px-3 flex items-center justify-center text-stone-400 hover:text-stone-100"
                  aria-label="Subscribe"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              {subscribed && (
                <p className="text-[11px] text-emerald-400 flex items-center space-x-1">
                  <span>✓ Subscribed to Oppenheim Journal.</span>
                </p>
              )}
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-stone-800/80 flex flex-col sm:flex-row items-center justify-between text-[11px] text-stone-500 font-light space-y-4 sm:space-y-0">
          <p>© {new Date().getFullYear()} Oppenheim Architecture. All Rights Reserved.</p>
          <div className="flex items-center space-x-6">
            <span>Miami • Basel • New York</span>
            <button
              onClick={scrollToTop}
              className="flex items-center space-x-1 hover:text-stone-200 transition-colors uppercase tracking-widest text-[10px]"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
