import React, { useState } from "react";
import { BOOKS_DATA } from "../data/studioData";
import { BookPublication } from "../types";
import { BookOpen, ExternalLink, X, Maximize2 } from "lucide-react";

export const PublicationsView: React.FC = () => {
  const [selectedBook, setSelectedBook] = useState<BookPublication | null>(null);

  return (
    <div id="publications-page-container" className="pt-24 pb-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="border-b border-stone-200 dark:border-stone-800 pb-8">
          <p className="text-xs uppercase tracking-[0.35em] text-stone-500 font-mono mb-2">
            Monographs & Literature
          </p>
          <h1 className="text-4xl sm:text-6xl font-serif font-light text-stone-900 dark:text-stone-50 tracking-wide">
            Books & Publications
          </h1>
          <p className="text-base text-stone-600 dark:text-stone-400 font-light mt-4 max-w-2xl">
            Authored and edited by Chad Oppenheim, exploring radical villainous hideouts, site philosophy, and 25 years of elemental architecture.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {BOOKS_DATA.map((book) => (
            <div
              key={book.id}
              className="bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-8 flex flex-col justify-between"
            >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-6">
                <div className="sm:col-span-1 bg-stone-950 p-2 border border-stone-800 flex items-center justify-center">
                  <img
                    src={book.coverImage}
                    alt={book.title}
                    className="w-full h-auto object-cover shadow-lg"
                  />
                </div>
                <div className="sm:col-span-2 space-y-3">
                  <p className="text-xs font-mono text-amber-800 dark:text-amber-400 uppercase tracking-widest">
                    {book.publisher} • {book.year}
                  </p>
                  <h3 className="text-2xl font-serif text-stone-900 dark:text-stone-100 leading-snug">
                    {book.title}
                  </h3>
                  <p className="text-xs font-serif italic text-stone-500 dark:text-stone-400">
                    {book.subtitle}
                  </p>
                  <p className="text-xs text-stone-600 dark:text-stone-400 font-light leading-relaxed line-clamp-4">
                    {book.description}
                  </p>
                </div>
              </div>

              <div className="pt-6 border-t border-stone-200 dark:border-stone-800 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
                <span className="text-stone-500">ISBN: {book.isbn} • {book.pages} Pages</span>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => setSelectedBook(book)}
                    className="px-4 py-2 border border-stone-300 dark:border-stone-700 text-stone-800 dark:text-stone-200 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors uppercase tracking-wider text-[11px]"
                  >
                    Preview Spreads
                  </button>
                  <a
                    href={book.purchaseUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 hover:opacity-90 transition-opacity uppercase tracking-wider text-[11px] font-semibold flex items-center space-x-1"
                  >
                    <span>Order Book</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Spread Preview Modal */}
      {selectedBook && (
        <div className="fixed inset-0 z-50 bg-stone-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-stone-800 max-w-4xl w-full p-8 relative text-stone-100">
            <button
              onClick={() => setSelectedBook(null)}
              className="absolute top-4 right-4 p-2 text-stone-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
            <h3 className="text-2xl font-serif text-white mb-2">{selectedBook.title}</h3>
            <p className="text-xs font-mono text-stone-400 mb-6">Interior Page Spreads & Drawings</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {selectedBook.spreadImages.map((img, i) => (
                <img
                  key={i}
                  src={img}
                  alt={`Spread ${i + 1}`}
                  className="w-full h-60 object-cover border border-stone-800"
                />
              ))}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setSelectedBook(null)}
                className="px-6 py-2 bg-stone-100 text-stone-900 uppercase font-mono text-xs tracking-widest font-semibold"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
