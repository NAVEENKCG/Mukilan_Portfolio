import React, { useState, useEffect, useRef } from "react";
import { X, Sparkles, Send, Loader2, Bot, User, RefreshCw } from "lucide-react";

interface AiConsultantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
}

interface ChatMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  time: string;
}

export const AiConsultantDrawer: React.FC<AiConsultantDrawerProps> = ({
  isOpen,
  onClose,
  initialPrompt,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-msg",
      sender: "ai",
      text: "Greetings. I am the Oppenheim AI Architectural Consultant. You may ask me about our 25-year portfolio, material palettes, 'Design Following Life' principles, or request site design recommendations.",
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleSendMessage(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  if (!isOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: "user",
      text,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputText("");
    setLoading(true);

    try {
      const response = await fetch("/api/ai-consultant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      const data = await response.json();

      if (data.reply) {
        const aiMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          sender: "ai",
          text: data.reply,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        };
        setMessages((prev) => [...prev, aiMsg]);
      } else {
        throw new Error(data.error || "Failed to receive AI response.");
      }
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: "ai",
        text: "Oppenheim Architecture philosophy emphasizes harmony with nature. (Note: Ensure GEMINI_API_KEY is configured in runtime environment if server connection is unreachable).",
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    "What is the 'Design Following Life' philosophy?",
    "Tell me about Desert Rock Resort materials",
    "How does Oppenheim approach desert architecture?",
    "Which projects won Cooper Hewitt awards?",
  ];

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-md flex justify-end">
      <div className="bg-stone-50 dark:bg-stone-900 border-l border-stone-200 dark:border-stone-800 text-stone-900 dark:text-stone-100 w-full max-w-lg h-full flex flex-col justify-between p-6">
        {/* Header */}
        <div>
          <div className="flex items-center justify-between border-b border-stone-200 dark:border-stone-800 pb-4 mb-4">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              <div>
                <h3 className="text-lg font-serif text-stone-900 dark:text-white">AI Studio Consultant</h3>
                <p className="text-[10px] font-mono text-amber-700 dark:text-amber-400">Powered by Gemini 2.5 Flash</p>
              </div>
            </div>
            <button onClick={onClose} className="p-1.5 text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Prompts */}
          <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar pb-3 mb-2">
            {samplePrompts.map((prompt, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(prompt)}
                className="px-2.5 py-1 bg-white dark:bg-stone-950 border border-stone-200 dark:border-stone-800 hover:border-amber-500 dark:hover:border-amber-400 text-[10px] font-mono text-stone-700 dark:text-stone-300 whitespace-nowrap transition-colors shrink-0 shadow-xs"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>

        {/* Messages Feed */}
        <div className="flex-1 overflow-y-auto my-4 space-y-4 pr-1 no-scrollbar">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex space-x-3 text-xs leading-relaxed ${
                msg.sender === "user" ? "justify-end" : "justify-start"
              }`}
            >
              {msg.sender === "ai" && (
                <div className="w-7 h-7 rounded-full bg-amber-100 dark:bg-amber-900/60 border border-amber-300 dark:border-amber-700/50 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-amber-800 dark:text-amber-300" />
                </div>
              )}
              <div
                className={`p-3.5 max-w-[85%] ${
                  msg.sender === "user"
                    ? "bg-stone-900 text-stone-50 dark:bg-stone-100 dark:text-stone-900 font-sans font-medium shadow-xs"
                    : "bg-white dark:bg-stone-950 text-stone-800 dark:text-stone-200 border border-stone-200 dark:border-stone-800 font-light shadow-xs"
                }`}
              >
                <p className="whitespace-pre-line">{msg.text}</p>
                <span className="block text-[9px] font-mono text-stone-400 dark:text-stone-500 text-right mt-1.5">
                  {msg.time}
                </span>
              </div>
              {msg.sender === "user" && (
                <div className="w-7 h-7 rounded-full bg-stone-200 dark:bg-stone-800 flex items-center justify-center shrink-0">
                  <User className="w-4 h-4 text-stone-700 dark:text-stone-300" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-2 text-xs font-mono text-amber-700 dark:text-amber-400 p-2">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Synthesizing architectural insight...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="border-t border-stone-200 dark:border-stone-800 pt-4"
        >
          <div className="relative flex items-center">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask AI Consultant about Oppenheim works..."
              className="w-full bg-white dark:bg-stone-950 border border-stone-300 dark:border-stone-800 px-4 py-3 text-xs text-stone-900 dark:text-stone-100 placeholder-stone-400 dark:placeholder-stone-500 focus:outline-none focus:border-amber-500 dark:focus:border-amber-400 pr-12 font-mono"
            />
            <button
              type="submit"
              disabled={loading || !inputText.trim()}
              className="absolute right-2 p-2 text-stone-500 dark:text-stone-400 hover:text-amber-600 dark:hover:text-amber-400 disabled:opacity-40"
              aria-label="Send"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
