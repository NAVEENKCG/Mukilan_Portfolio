import { Project } from "../types";

export const PROJECTS_DATA: Project[] = [
  {
    id: "desert-rock",
    title: "Desert Rock Resort",
    subtitle: "Carved Mountain Sanctuary in the Ancient Hejaz Terrain",
    category: "Hospitality",
    location: "Riyadh Region, Saudi Arabia",
    year: 2024,
    area: "65,000 sq.m / 700,000 sq.ft",
    status: "In Construction",
    heroImage: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1541888946425-d0fbb186a5b3?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "A world-first eco-resort integrated directly into the granite mountains, honoring ancient Nabataean cliff-carving tradition.",
    longDescription: "Desert Rock allows guests to inhabit the majesty of the ancient Hejaz Mountains without disturbing the physical topography. Villas are either integrated into the ground, built on top of the rock plateau, or excavated straight into the granite mountain face. Utilizing stone excavated during construction to form concrete walls and interior finishes, the resort achieves a seamless material dialogue with the surrounding environment.",
    highlights: [
      "Excavated mountain-face suites carved directly into granite cliff walls",
      "LEED Gold certification targeting zero-light pollution stargazing zones",
      "Local stone aggregate concrete mix matching mountain mineral tones",
      "Natural subterranean cooling channels inspired by ancient desert hydrology"
    ],
    materials: ["Native Granite Stone", "pigmented Shotcrete", "Reclaimed Timber", "Bronze Metal mesh"],
    awards: [
      "MNDA National Architectural Design Award 2023",
      "AIA Florida Unbuilt Honor Award 2022",
      "World Architecture Festival (WAF) Future Project Winner"
    ],
    team: ["Chad Oppenheim", "Beat Huesler", "Kevin Heidorn", "Tom Llewellyn"],
    client: "Red Sea Global (RSG)",
    featured: true,
    aspectRatio: "aspect-[16/9]",
    coordinates: { lat: 26.551, lng: 37.948 },
    quote: {
      text: "Desert Rock is not designed to sit on top of the landscape, but to arise from within it — revealing the raw essence of the mountain.",
      author: "Chad Oppenheim, Design Principal"
    },
    diagrams: [
      {
        title: "Subterranean Mountain Excavation & Solar Orientation",
        image: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&q=80&w=1000"
      },
      {
        title: "Material Harmony & Excavated Stone Aggregate Flow",
        image: "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&q=80&w=1000"
      }
    ]
  },
  {
    id: "ayla-golf-clubhouse",
    title: "Ayla Golf Clubhouse",
    subtitle: "Undulating Shotcrete Shell Mirrored Against Desert Dunes",
    category: "Hospitality",
    location: "Aqaba, Jordan",
    year: 2018,
    area: "5,800 sq.m / 62,400 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "An architectural landmark featuring a continuous shotcrete shell that surges out of the desert sands like a natural dune.",
    longDescription: "The Ayla Golf Clubhouse forms the central focal point of a 17-square-mile resort development in Aqaba. Its distinctive architectural form creates an intimate connection with the surrounding mountains and desert context. A continuous concrete shell envelops the building, framing views of the Aqaba Gulf and surrounding mountain peaks. Local Bedouin artisans were trained to apply the pigmented shotcrete coating, embedding hand-crafted craftsmanship into the structure.",
    highlights: [
      "Custom-formulated orange-pigmented concrete mix derived from regional sands",
      "Hand-crafted corten steel screens featuring traditional Mashrabiya perforation patterns",
      "Zero mechanical cooling required in central public thoroughfares due to passive wind funnels",
      "Collaborative construction training initiative with local Jordanian craftspeople"
    ],
    materials: ["Pigmented Shotcrete", "Corten Steel", "Local Aqaba Stone", "Polished Terrazzo"],
    awards: [
      "AIA National Honor Award for Architecture 2020",
      "Cooper Hewitt National Design Award 2018",
      "Architizer A+ Award Jury Winner"
    ],
    team: ["Chad Oppenheim", "Beat Huesler", "Juan Calvo"],
    client: "Ayla Oasis Development Company",
    featured: true,
    aspectRatio: "aspect-[4/3]",
    coordinates: { lat: 29.548, lng: 34.981 },
    quote: {
      text: "The building feels as though it was sculpted by desert winds over centuries, standing silently between sea and mountain.",
      author: "Beat Huesler, Director European Operations"
    }
  },
  {
    id: "escondido-beach",
    title: "Escondido Beach Residence",
    subtitle: "Monolithic Coastal Haven Carved for Oceanfront Living",
    category: "Residential",
    location: "Malibu, California, USA",
    year: 2021,
    area: "850 sq.m / 9,150 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "A radical transformation of a beachfront property into a brutalist coastal sanctuary prioritizing tactile simplicity.",
    longDescription: "Perched along the edge of the Pacific Ocean in Malibu, Escondido Beach strips away non-essential elements to focus entirely on light, sea, and rock. Through the strategic use of board-formed concrete, bleached oak, and hand-troweled plaster, the home offers panoramic marine perspectives while providing a fortress-like privacy from the coastal road.",
    highlights: [
      "Custom motorized pocketing glass walls opening 40 feet of living room directly to tide lines",
      "Board-formed concrete exterior weathered naturally by marine salt air",
      "Sunken courtyard garden providing relief from prevailing sea breezes",
      "Integrated solar array hidden behind parapet roof profiles"
    ],
    materials: ["Board-Formed Concrete", "Bleached White Oak", "Travertine Stone", "Bronze Hardware"],
    awards: [
      "AIA Los Angeles Residential Design Award 2022",
      "Architectural Record House of the Year"
    ],
    team: ["Chad Oppenheim", "Kevin Heidorn", "Carl Pascuzzi"],
    client: "Private Client",
    featured: true,
    aspectRatio: "aspect-[3/4]",
    coordinates: { lat: 34.025, lng: -118.771 },
    quote: {
      text: "Every frame in this home is calibrated to turn the Pacific Ocean into living artwork.",
      author: "Chad Oppenheim"
    }
  },
  {
    id: "muttenz-water-plant",
    title: "Muttenz Water Purification Plant",
    subtitle: "Civic Monument and Hydro-Educational Landmark",
    category: "Commercial & Mixed-Use",
    location: "Muttenz, Switzerland",
    year: 2017,
    area: "3,200 sq.m / 34,400 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "A water purification plant disguised as a monolith carved by natural water erosion in the Swiss forest.",
    longDescription: "Located adjacent to the Rhine river forest in Basel-Land, this state-of-the-art facility purifies water for the town of Muttenz while educating visitors on environmental conservation. The facade is rendered in Shotcrete mixed with clay and local river gravel, intentionally allowing moss and rain to age the building over time into the forest ecosystem.",
    highlights: [
      "Facade made of porous earth-tone Shotcrete that fosters natural moss growth",
      "Elevated public educational gallery overlooking central water purification tanks",
      "Rainwater harvesting roof garden filtering stormwater through natural reeds",
      "Minimal energy consumption aided by subterranean thermal mass insulation"
    ],
    materials: ["Earthy Shotcrete", "Galvanized Steel", "Translucent Glass", "Exposed Rebar details"],
    awards: [
      "AIA Europe Honor Award 2018",
      "Swiss Architecture Award Nominee",
      "European Design Award for Civic Architecture"
    ],
    team: ["Beat Huesler", "Chad Oppenheim", "Frederic Snella"],
    client: "Municipality of Muttenz",
    featured: true,
    aspectRatio: "aspect-[16/9]",
    coordinates: { lat: 47.523, lng: 7.645 },
    quote: {
      text: "The building becomes a canvas for nature, aging gracefully as moss and rain wash across its porous skin.",
      author: "Beat Huesler"
    }
  },
  {
    id: "star-metals-residences",
    title: "Star Metals Residences",
    subtitle: "Industrial Heritage Tower in West Midtown Atlanta",
    category: "Commercial & Mixed-Use",
    location: "Atlanta, Georgia, USA",
    year: 2020,
    area: "42,000 sq.m / 450,000 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "A 14-story residential tower celebrating West Midtown's historic railway and metalworking history.",
    longDescription: "Star Metals Residences infuses urban vitality into Atlanta's West Midtown district. Inspired by the area's rich industrial rail yards, the building utilizes weathered steel panels, blackened iron mullions, and exposed concrete. A 20,000 sq ft rooftop park features infinity lap pools, fire pits, and co-working lounges framing views of the Atlanta skyline.",
    highlights: [
      "Corten steel exterior cladding reflecting historic iron scrap yards",
      "Rooftop urban meadow with native Georgia flora and panoramic city views",
      "Ground-floor art-activated public pedestrian arcade connecting rail lines",
      "High-efficiency double-paned acoustic glass dampening train track audio"
    ],
    materials: ["Corten Steel", "Blackened Steel", "Raw Concrete", "Architectural Glass"],
    awards: ["ULI Americas Award for Excellence 2021", "AIA Georgia Design Award"],
    team: ["Chad Oppenheim", "Kevin Heidorn", "Alexis Bormann"],
    client: "The Allen Morris Company",
    featured: false,
    aspectRatio: "aspect-[3/4]",
    coordinates: { lat: 33.782, lng: -84.412 }
  },
  {
    id: "house-on-a-dune",
    title: "House on a Dune",
    subtitle: "Barefoot Luxury on Harbour Island's Pink Sands",
    category: "Residential",
    location: "Harbour Island, Bahamas",
    year: 2016,
    area: "320 sq.m / 3,450 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "An elegant, low-profile beach house crafted from native coral stone and Brazilian ipe wood.",
    longDescription: "Resting lightly upon a natural dune ridge overlooking the Atlantic, House on a Dune reinterprets classical Bahamian plantation architecture through hyper-minimalism. Wide roof overhangs provide shade, while floor-to-ceiling louvered doors allow tropical trade winds to naturally ventilate the home without air conditioning.",
    highlights: [
      "Zero-footprint pile foundation preserving fragile dune vegetation",
      "Reclaimed Ipe wood decking and hand-carved coral limestone blocks",
      "Passive ventilation system utilizing trade winds",
      "Off-grid solar generation with rainwater harvesting cistern"
    ],
    materials: ["Coral Limestone", "Ipe Wood", "Cedar Shingles", "Stainless Steel"],
    awards: ["AIA Miami Honor Award", "Interior Design Magazine Best of Year"],
    team: ["Chad Oppenheim", "Juan Calvo"],
    client: "Private Residence",
    featured: true,
    aspectRatio: "aspect-[4/3]",
    coordinates: { lat: 25.501, lng: -76.634 }
  },
  {
    id: "la-villa-michael-bay",
    title: "Bel Air Ridge Villa (L.A. Villa)",
    subtitle: "Suspended Glass & Concrete Hilltop Residence",
    category: "Residential",
    location: "Los Angeles, California, USA",
    year: 2019,
    area: "1,800 sq.m / 19,500 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "A cinematic cantilevered residence overlooking downtown Los Angeles and Santa Monica mountain ridges.",
    longDescription: "Commissioned by filmmaker Michael Bay, this extraordinary hilltop estate consists of two floating cantilevered concrete volumes perched above a glass box. Designed to showcase dramatic art collections and vehicle design, the home features a subterranean theater, wine vault, and a 100-foot infinity edge pool framing the LA basin.",
    highlights: [
      "40-foot cantilevered upper master suite floating over cliff edge",
      "Subterranean screening theater crafted with state-of-the-art acoustic dampening",
      "100-foot infinity edge pool creating a seamless boundary with the LA sky",
      "Custom subterranean car gallery showcasing historic automotive design"
    ],
    materials: ["High-Performance Concrete", "Starphire Low-Iron Glass", "Basalt Stone", "Polished Steel"],
    awards: ["AIA Los Angeles Honor Award", "Robb Report Best Architectural Home"],
    team: ["Chad Oppenheim", "Kevin Heidorn", "Juan Calvo"],
    client: "Michael Bay",
    featured: true,
    aspectRatio: "aspect-[16/9]",
    coordinates: { lat: 34.083, lng: -118.441 }
  },
  {
    id: "emiliano-hotel-rio",
    title: "Emiliano Hotel Copacabana",
    subtitle: "Perforated Kinetic Facade Beachfront Landmark",
    category: "Hospitality",
    location: "Rio de Janeiro, Brazil",
    year: 2017,
    area: "9,200 sq.m / 99,000 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "A tropical modern hotel featuring an articulated skin that opens dynamically to Copacabana Beach.",
    longDescription: "In collaboration with Studio Arthur Casas, Oppenheim Architecture crafted the beachfront hotel as a tribute to Brazilian mid-century modernism. The facade features kinetic weather-proof panels with geometric cutouts that guests can manipulate to filter sunlight, ocean views, and sea breezes.",
    highlights: [
      "Operable fiberglass screen panels creating an evolving geometric facade pattern",
      "Rooftop infinity pool overlooking Sugarloaf Mountain and Atlantic coastline",
      "Interior vertical garden courtyards featuring native Amazonian flora",
      "Acoustic isolation glass dampening Atlantic Avenue beach traffic sound"
    ],
    materials: ["Perforated Fiberglass", "Calacatta Marble", "Brazilian Walnut", "White Stucco"],
    awards: ["WAF Hospitality Building of the Year", "Architectural Digest Hotel Award"],
    team: ["Chad Oppenheim", "Studio Arthur Casas"],
    client: "Hotel Emiliano",
    featured: false,
    aspectRatio: "aspect-[3/4]",
    coordinates: { lat: -22.971, lng: -43.182 }
  },
  {
    id: "wadi-rum-resort",
    title: "Wadi Rum Eco-Lodge",
    subtitle: "Subterranean Desert Sanctuary carved into Sandstone Bluffs",
    category: "Masterplanning",
    location: "Wadi Rum, Jordan",
    year: 2025,
    area: "120,000 sq.m / 1,290,000 sq.ft",
    status: "Concept",
    heroImage: "https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "A masterplan for subterranean habitat modules carved directly into rose-pink sandstone canyons.",
    longDescription: "Wadi Rum Eco-Lodge establishes a sustainable paradigm for desert hospitality. By carving guest accommodations into deep sandstone crevices, thermal mass maintains 21°C indoor temperatures year-round without mechanical HVAC. Solar energy and dew-harvesting networks enable total self-sufficiency.",
    highlights: [
      "Zero-carbon footprint passive thermal mass subterranean architecture",
      "Sandstone powder concrete composite structures",
      "Astronomical observatory integrated into canyon rim plateau"
    ],
    materials: ["Rose Sandstone", "Earth Mortar", "Patinated Copper"],
    awards: ["MNDA Visionary Masterplan Award 2024"],
    team: ["Chad Oppenheim", "Beat Huesler"],
    client: "Jordanian Tourism Authority",
    featured: true,
    aspectRatio: "aspect-[16/9]",
    coordinates: { lat: 29.571, lng: 35.421 }
  },
  {
    id: "kirchplatz-residence",
    title: "Kirchplatz Historic Farmsteads",
    subtitle: "18th-Century Timber & Stone Adaptation in Muttenz",
    category: "Interior Design",
    location: "Muttenz, Switzerland",
    year: 2019,
    area: "1,200 sq.m / 12,900 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "Adaptive reuse of a historic 1743 Swiss timber barn into a contemporary office and cultural gallery.",
    longDescription: "Situated in the protected village core of Muttenz, Kirchplatz honors 300-year-old timber framing while introducing raw black steel staircases and frameless triple-glazed window inserts. It houses Oppenheim Architecture's European headquarters.",
    highlights: [
      "Restoration of historic oak timber trusses dating back to 1743",
      "Black steel spatial inserts separating public galleries from private studios",
      "Geothermal floor heating beneath reclaimed cobblestone"
    ],
    materials: ["Reclaimed 1740 Oak", "Raw Steel", "Limestone Mortar", "Clear Glass"],
    awards: ["Swiss Heritage Conservation Honor 2020"],
    team: ["Beat Huesler", "Frederic Snella"],
    client: "Oppenheim Architecture Europe",
    featured: false,
    aspectRatio: "aspect-[4/3]",
    coordinates: { lat: 47.522, lng: 7.646 }
  },
  {
    id: "ten-museum-park",
    title: "Ten Museum Park",
    subtitle: "50-Story Crystalline Sky-Villa Tower in Biscayne Bay",
    category: "Commercial & Mixed-Use",
    location: "Miami, Florida, USA",
    year: 2007,
    area: "48,000 sq.m / 516,000 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "A groundbreaking 50-story residential tower introducing double-height loft villas and rooftop dip pools.",
    longDescription: "Ten Museum Park transformed Downtown Miami's skyline upon completion in 2007. Featuring a crystalline glass skin that reflects Biscayne Bay, the tower houses 200 residences equipped with individual plunge pools on cantilevered sky decks.",
    highlights: [
      "First residential tower with private rooftop plunge pools for upper sky lofts",
      "20,000 sq.ft Clinique La Prairie wellness spa facility",
      "Impact-resistant reflective curtainwall withstand Category 5 hurricanes"
    ],
    materials: ["High-Reflective Glass", "Structural Steel", "White Terrazzo"],
    awards: ["AIA Miami Building of the Year 2008"],
    team: ["Chad Oppenheim", "Juan Calvo"],
    client: "Gregg Covin & Louis Birdman",
    featured: false,
    aspectRatio: "aspect-[3/4]",
    coordinates: { lat: 25.783, lng: -80.191 }
  },
  {
    id: "glf-headquarters",
    title: "GLF Construction Headquarters",
    subtitle: "Floating Cantilevered Glass Volumes on Miami River",
    category: "Commercial & Mixed-Use",
    location: "Miami, Florida, USA",
    year: 2015,
    area: "3,800 sq.m / 41,000 sq.ft",
    status: "Completed",
    heroImage: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1600",
    images: [
      "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1600",
      "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=1600"
    ],
    description: "An office building configured as stacked shipping containers floating over the working Miami River.",
    longDescription: "Reflecting GLF's marine engineering pedigree, the headquarters is composed of stacked steel volumes cantilevered over the water's edge. Outdoor garden terraces on every floor offer views of cargo ships navigating the waterway.",
    highlights: [
      "35-foot structural steel cantilevers floating over active boat docks",
      "Natural daylighting in 95% of workspace interiors",
      "Rooftop solar garden offsetting 40% of building energy load"
    ],
    materials: ["Structural I-Beams", "Marine-Grade Aluminum", "Insulated Low-E Glass"],
    awards: ["AIA Florida Honor Award 2016"],
    team: ["Chad Oppenheim", "Kevin Heidorn"],
    client: "GLF Construction Corporation",
    featured: false,
    aspectRatio: "aspect-[16/9]",
    coordinates: { lat: 25.776, lng: -80.201 }
  }
];
