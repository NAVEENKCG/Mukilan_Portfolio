import { StudioOffice, TeamMember, AwardItem, BookPublication, CareerRole } from "../types";

export const OFFICES: StudioOffice[] = [
  {
    id: "miami",
    city: "Miami",
    country: "USA",
    address: "2500 NW 2nd Avenue, Suite 100, Miami, FL 33127",
    phone: "+1 (305) 573-2256",
    email: "miami@oppenoffice.com",
    coordinates: { lat: 25.801, lng: -80.199 },
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1200",
    manager: "Chad Oppenheim & Kevin Heidorn",
    timezone: "EST (UTC-5)"
  },
  {
    id: "basel",
    city: "Basel",
    country: "Switzerland",
    address: "Kirchplatz 14, 4132 Muttenz / Basel, Switzerland",
    phone: "+41 61 463 88 00",
    email: "basel@oppenoffice.com",
    coordinates: { lat: 47.523, lng: 7.645 },
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200",
    manager: "Beat Huesler",
    timezone: "CET (UTC+1)"
  },
  {
    id: "new-york",
    city: "New York",
    country: "USA",
    address: "1123 Broadway, Suite 901, New York, NY 10010",
    phone: "+1 (212) 352-0900",
    email: "nyc@oppenoffice.com",
    coordinates: { lat: 40.743, lng: -73.988 },
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200",
    manager: "Juan Calvo",
    timezone: "EST (UTC-5)"
  }
];

export const PHILOSOPHY_PILLARS = [
  {
    number: "01",
    title: "Design Following Life",
    summary: "Architecture should be tailored to human ritual, emotion, and sensory perception rather than artificial ornamentation.",
    details: "We believe that form follows feeling. Every spatial volume is designed around the choreography of daily life — how sunlight enters a room at dawn, how winds move across stone, and how people interact with landscape."
  },
  {
    number: "02",
    title: "Monolithic & Subtractive",
    summary: "Creating architecture by carving away non-essential elements to expose the primal essence of place.",
    details: "Rather than adding decorative layers, we subtract. Our projects are carved into hillsides, sculpted from desert sands, or etched into urban blocks — revealing pure geometry that feels as ancient as it does futuristic."
  },
  {
    number: "03",
    title: "Elemental Symbiosis",
    summary: "Harmonizing with nature using local minerals, native aggregate, and climate-responsive engineering.",
    details: "We use native stone, site-excavated gravel, and regional woods so buildings age naturally with their surroundings. Passive solar orientation, natural cross-breezes, and thermal mass reduce ecological footprint."
  },
  {
    number: "04",
    title: "Craftsmanship & Humanity",
    summary: "Partnering with local artisans to embed human touches into contemporary engineering.",
    details: "From Bedouin shotcrete applicators in Jordan to Swiss timber restorers in Muttenz, we collaborate with local craftspeople to ensure every building reflects regional heritage and human mastery."
  }
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    id: "chad-oppenheim",
    name: "Chad Oppenheim",
    role: "Founder & Design Principal",
    office: "Miami / New York",
    bio: "FAIA member and Cooper Hewitt National Design Award laureate. Founded Oppenheim Architecture in 1999 with a vision to create romantic, ecologically sensitive architecture. Author of 'Lair: Radical Homes of Supervillains' and 'Spirit of the Place'.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "beat-huesler",
    name: "Beat Huesler",
    role: "Director of European Operations",
    office: "Basel",
    bio: "Leads European endeavors from the Muttenz studio. Expert in adaptive reuse, European civic infrastructure, and precise timber-and-concrete construction.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "kevin-heidorn",
    name: "Kevin Heidorn",
    role: "Principal Architect",
    office: "Miami",
    bio: "Over 18 years at Oppenheim Architecture managing complex international masterplans including Desert Rock Saudi Arabia and Star Metals Atlanta.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "juan-calvo",
    name: "Juan Calvo",
    role: "Director of Design",
    office: "New York",
    bio: "Directs conceptual design across residential and cultural commissions, specializing in high-contrast volumetric compositions and spatial choreography.",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=800"
  }
];

export const AWARDS_LIST: AwardItem[] = [
  { year: "2023", award: "National Design Award for Architecture", project: "Lifetime Achievement", organization: "Cooper Hewitt Museum" },
  { year: "2023", award: "MNDA Architectural Design Honor", project: "Desert Rock Resort", organization: "Middle East Architecture Society" },
  { year: "2022", award: "AIA Florida Unbuilt Honor Award", project: "Desert Rock Resort", organization: "American Institute of Architects" },
  { year: "2021", award: "ULI Americas Award for Excellence", project: "Star Metals Residences", organization: "Urban Land Institute" },
  { year: "2020", award: "AIA National Honor Award for Architecture", project: "Ayla Golf Clubhouse", organization: "American Institute of Architects" },
  { year: "2019", award: "Architizer A+ Jury Winner", project: "Ayla Golf Clubhouse", organization: "Architizer" },
  { year: "2018", award: "AIA Europe Honor Award", project: "Muttenz Water Purification Plant", organization: "AIA Europe" },
  { year: "2018", award: "Cooper Hewitt National Design Award", project: "Interior Design Excellence", organization: "Smithsonian Institution" },
  { year: "2017", award: "World Architecture Festival (WAF) Winner", project: "Emiliano Hotel Rio", organization: "WAF" },
  { year: "2016", award: "AIA Florida Honor Award", project: "GLF Headquarters", organization: "AIA Florida" },
  { year: "2015", award: "AIA Miami Architectural Firm of the Year", project: "Studio Portfolio", organization: "AIA Miami" }
];

export const BOOKS_DATA: BookPublication[] = [
  {
    id: "lair-supervillains",
    title: "Lair: Radical Homes of Supervillains",
    subtitle: "Architectural Examination of Iconic Cinematic Villains' Habitats",
    publisher: "Tra Publishing",
    year: "2019",
    coverImage: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=800",
    spreadImages: [
      "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=1200"
    ],
    description: "Edited by Chad Oppenheim, 'Lair' explores the iconic villain structures in cinema history — from James Bond retreats to futuristic monoliths — analyzing their architectural floorplans, structural physics, and psychological impact.",
    isbn: "978-0998632605",
    pages: 296,
    purchaseUrl: "https://trapublishing.com/products/lair-radical-homes-and-hideouts-of-movie-villains"
  },
  {
    id: "spirit-of-the-place",
    title: "Spirit of the Place",
    subtitle: "Oppenheim Architecture Monograph on Elemental Harmony",
    publisher: "Tra Publishing",
    year: "2018",
    coverImage: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=800",
    spreadImages: [
      "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200"
    ],
    description: "A visually compelling monograph documenting two decades of Oppenheim Architecture projects across 25 countries. Captures raw land encounters, site sketches, material studies, and finished photographs.",
    isbn: "978-0998632612",
    pages: 320,
    purchaseUrl: "https://trapublishing.com/products/spirit-of-the-place"
  }
];

export const CAREER_ROLES: CareerRole[] = [
  {
    id: "senior-architect-miami",
    title: "Senior Project Architect",
    office: "Miami Studio",
    type: "Full-Time",
    experience: "8-12 Years",
    description: "Leading technical development, BIM coordination, and client management for luxury hospitality and mountain resort developments.",
    requirements: [
      "Master of Architecture degree or professional equivalent",
      "Proficiency in Revit, Rhino, Enscape, and Adobe Creative Suite",
      "Proven experience in high-end hospitality and heavy concrete/stone detailing",
      "Architectural License in Florida or NCARB certification required"
    ]
  },
  {
    id: "project-designer-basel",
    title: "Project Designer",
    office: "Basel Studio",
    type: "Full-Time",
    experience: "4-7 Years",
    description: "Focusing on European civic competitions, adaptive reuse projects, and parametric shotcrete formwork.",
    requirements: [
      "Master of Architecture degree from accredited European or international university",
      "Fluency in German and English (French is a plus)",
      "Strong physical modelmaking and Rhino 3D parametric skills",
      "In-depth knowledge of Swiss SIA standards and construction codes"
    ]
  }
];
