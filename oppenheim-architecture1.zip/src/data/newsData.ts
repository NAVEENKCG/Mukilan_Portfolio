import { NewsArticle } from "../types";

export const NEWS_ARTICLES: NewsArticle[] = [
  {
    id: "desert-rock-unveiled",
    title: "Desert Rock Resort Carved into Hejaz Mountains Reaches Construction Milestone",
    category: "Press Release",
    date: "January 24, 2025",
    publication: "ArchDaily & Dezeen",
    summary: "Excavation of mountain-face suites is now 80% complete at the Red Sea Global destination in Saudi Arabia.",
    content: "Desert Rock Resort, designed by Oppenheim Architecture, has reached a critical structural milestone. The project excavates granite mountain faces to insert subterranean guest suites while using the stone byproduct for local shotcrete mix. The resort is scheduled to open later this year.",
    image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&q=80&w=1200",
    readTime: "4 min read",
    featured: true
  },
  {
    id: "cooper-hewitt-national-award",
    title: "Oppenheim Architecture Honored with Cooper Hewitt National Design Award",
    category: "Award",
    date: "November 12, 2024",
    publication: "Smithsonian Cooper Hewitt Museum",
    summary: "Recognizing 25 years of elemental design, environmental craftsmanship, and spatial innovation.",
    content: "The Smithsonian's Cooper Hewitt, National Design Museum has awarded Oppenheim Architecture the National Design Award for Interior & Spatial Design. The jury commended the studio's commitment to 'Design Following Life' across 25 countries.",
    image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=1200",
    readTime: "3 min read",
    featured: true
  },
  {
    id: "ayla-golf-clubhouse-wallpaper",
    title: "Ayla Golf Clubhouse Featured in Wallpaper* Design Awards Annual",
    category: "Feature",
    date: "August 18, 2024",
    publication: "Wallpaper* Magazine",
    summary: "An in-depth critique on how the shotcrete undulating form harmonizes with Aqaba's desert topography.",
    content: "Wallpaper* explores the hand-crafted shotcrete geometry of Ayla Golf Clubhouse. Built with the assistance of local Bedouin artisans, the orange-hued concrete shell creates a seamless dialogue between desert dunes and marine horizons.",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200",
    readTime: "5 min read"
  },
  {
    id: "lair-book-launch-ny",
    title: "Chad Oppenheim Delivers Keynote Address at Rizzoli Bookstore New York",
    category: "Lecture",
    date: "May 04, 2024",
    publication: "Architectural Digest",
    summary: "Discussing cinema, villainous retreats, and radical subterranean residential architecture.",
    content: "Design Principal Chad Oppenheim joined architectural critic Paul Goldberger at Rizzoli New York to discuss 'Lair: Radical Homes of Supervillains' and how pop culture depicts subterranean architecture.",
    image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=1200",
    readTime: "6 min read"
  }
];
