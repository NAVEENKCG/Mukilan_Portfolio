import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check endpoint
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", studio: "Oppenheim Architecture" });
  });

  // AI Consultant endpoint using @google/genai SDK
  app.post("/api/ai-consultant", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({
          error: "GEMINI_API_KEY is not configured in server environment."
        });
      }

      const { message, projectContext } = req.body;
      const ai = new GoogleGenAI({ apiKey });

      const prompt = `You are the principal architectural strategist at Oppenheim Architecture (oppenoffice.com).
Your design philosophy: "Design Following Life. Form Following Feeling."
You specialize in brutalist-organic monoliths, desert resorts carved into rock, sustainable site integration, native material palettes, and elemental luxury.

User Question: "${message}"
${projectContext ? `Context / Project Reference: ${JSON.stringify(projectContext)}` : ''}

Provide an articulate, inspiring, and professional response (2-3 concise paragraphs) addressing their question, offering architectural insights, material suggestions, or project analysis based on Oppenheim Architecture's portfolio.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      res.json({ reply: response.text });
    } catch (err: any) {
      console.error("AI Consultant Error:", err);
      res.status(500).json({ error: err.message || "Failed to generate AI response." });
    }
  });

  // Vite middleware for development vs Static serve for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
